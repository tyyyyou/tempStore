﻿/* vim: set et sw=4 ts=4 sts=4 fdm=marker ff=unix fenc=utf8 nobomb: */

/**
 * filename.js
 * @author xiaoqiang
 * @mail   qiang0902@126.com 
 * @Date
 */

Export = {
	platform: $.Constants.IOS,
	doc: null,
	savePath: null,
    isNinePatch: 0,     // 是否画点9图
    fixedWidth: 0,      // 固定宽输出
    fixedHeight: 0,     // 固定高输出
    imageOptim: 24,     // 默认png-24
    imageResize: 100,   // 缩放比例
	imageType: 0,
    suffix: "@2x",
    multiMerge: 0,      // 多个图层合并导出/单独导出，默认单独导出
    sameName: 0,        // 相同名称文件，0：覆盖，1：不覆盖
    isCustomDpi: 0,       // 自定义DPI
    isX3S: 0,            // ios 3X特殊模式
    iosDpi: {
        x1: 0,
        x2: 1,
        x3: 1
    },
    dpi: {
        'xxhdpi': 0,
        'xhdpi': 1,
        'hdpi': 1,
        'mdpi': 0,
        'ldpi': 0
    },
    customDpi: {
        xxhdpi: 1080,
        xhdpi: 720,
        hdpi: 480,
        mdpi: 320,
        ldpi: 240
    }
};

/**
 * 初始化一些基本变量
 */
Export.init = function() {
	try { 
		Export.doc = (app.documents.length > 0)? app.activeDocument : null;
        Export.savePath = new Folder(Folder.desktop.absoluteURI);   // 默认放到桌面
	} catch(e) {
        console_error($.fileName, $.line, e);
	}
};


/**
 * 导出选中图层
 */
Export.exportSelectLayer = function() {
    try {

        if (app.documents.length == 0) {
            alert('你想干什么？都没有打开过文档啊!');
            return;
        }
        var doc = Export.doc = app.activeDocument;

        var layers = CCLib.getSelectedLayersIdx();
        if (layers.length == 1) {
            Export.exportSingleLayer(null);
        } else if (layers.length > 1){
            if (Export.multiMerge == 1) {   // 合并导出
                // 将选中的多个图层复制到新文档，然后合并可见图层
                CCLib.duplicateLayers();
                var d = app.activeDocument;
                CCLib.mergeVisibleLayers();
                Export.exportSingleLayer(function() {
                    d.close(SaveOptions.DONOTSAVECHANGES);
                    //CCLib.deleteCurrentHistroyState();  // 恢复到上一个状态
                });
            } else {
                // 将选中的多个图层复制到新文档，然后导出所有图层
                CCLib.duplicateLayers();
                var d = app.activeDocument;
                var n = d.artLayers.add();
                n.name = "__cutterman_reserved";
                Export.exportAllLayers(function() {
                    d.close(SaveOptions.DONOTSAVECHANGES);
                });
            }
        } else {
            alert('您还没有选择一个图层');
        }

        return layers.length;
    } catch (e) {
        console_error($.fileName, $.line, e);
    }
};

/**
 * 导出所有图层
 */
Export.exportAllLayers = function(callback) {
    try {
        if (app.documents.length == 0) {
            alert('你想干什么？都没有打开过文档啊!');
            return;
        }

        var layers = app.activeDocument.layers;
        if (layers.length > 20) {
            if (!confirm('当前图层数量较多，导出期间不能停止，确定继续?')) {
                return;
            }
        }


        var idx = 0;    // 过滤掉第一个
        function doExportLayers() {
            if (idx < layers.length) {
                var layer = layers[idx];
                if (!Export.isValidLayer(layer)) {
                    idx++;
                    doExportLayers();
                    return;
                }
                app.activeDocument.activeLayer = layers[idx];
                idx++;
                Export.exportSingleLayer(doExportLayers);
            } else {
                layers = null;
                if (callback) {
                    callback();
                }
            }
        }

        doExportLayers();


    } catch(e) {
        console_error($.fileName, $.line, e);
    }
};

Export.exportNinePatch = function() {
    try {
        if (app.documents.length == 0) {
            alert('你想干什么？都没有打开过文档啊!');
            return;
        }
        Export.isNinePatch = 1;
        Export.exportSingleLayer(null);
    } catch (e) {
        console_error($.fileName, $.line, e);
    }
};

/**
 * 导出单个图层
 */
Export.exportSingleLayer = function(callback) {
    try {
        if (app.documents.length == 0) {
            alert('你想干什么？都没有打开过文档啊!');
            return;
        }

        if (Export.savePath == null || !Export.savePath.exists) {
            alert('你还没有选择保存路径!');
            return;
        }

        // 保存原生配置
        var originalRulerUnits = app.preferences.rulerUnits;
        var originalTypeUnits = app.preferences.typeUnits;
        app.preferences.rulerUnits = Units.PIXELS;
        app.preferences.typeUnits = TypeUnits.PIXELS;

        var currentDoc = app.activeDocument;
        var currentLayerName = currentDoc.activeLayer.name.toLowerCase().replace(' ', '-').replace('/', '-');
        var currentDocWidth = currentDoc.width.value;
        var currentDocHeight = currentDoc.height.value;

        var layerKind = currentDoc.activeLayer.kind;

        // 选区切图
        var selection = currentDoc.selection;
        var hasSelection = false;
        try {
            var s_arr = [];
            if (selection.bounds != null) {
                hasSelection = true;
                s_arr.push(parseInt(selection.bounds[0]));     // x1
                s_arr.push(parseInt(selection.bounds[1]));     // y1
                s_arr.push(parseInt(selection.bounds[2]) - parseInt(selection.bounds[0]));  // width
                s_arr.push(parseInt(selection.bounds[3]) - parseInt(selection.bounds[1]));  // height 

                var bound = currentDoc.activeLayer.bounds;
                var deltx = parseInt(bound[0]) - s_arr[0];
                var delty = parseInt(bound[1]) - s_arr[1];
                s_arr.push(deltx);
                s_arr.push(delty);
                console_debug(s_arr);
            }
        } catch(e) {
            hasSelection = false;
            console_error(e);
        }


		// 这里需要处理全局光的问题
		var angle = CCLib.getGlobalLightAngle();

        // 新建一个文档
        var newDoc = app.documents.add(
                currentDoc.width,
                currentDoc.height,
                currentDoc.resolution,
                currentLayerName,
                NewDocumentMode.RGB,
                DocumentFill.TRANSPARENT);
        app.activeDocument = currentDoc;
        currentDoc.activeLayer.duplicate(newDoc);	// 复制当前图层
        app.activeDocument = newDoc;
        CCLib.applyGlobalLight(angle, 30);



        // IOS
        if (Export.platform == $.Constants.IOS) {
            var isFixedSize = (Export.fixedWidth > 0 && Export.fixedHeight > 0);
            var dpis = ['x1', 'x2', 'x3'];
            var suffixs = ['@1x', '@2x', '@3x'];
            var export_types = {
                "640": [0.5, 1, 1.5],
                "0": [1/3, 2/3, 1],
                "1": [1/3, 640/currentDocWidth, 1],
                "2": [320/currentDocWidth, 640/currentDocWidth, 640*1.5/currentDocWidth]
            };
            var fixed_size_types = {
                "640": [0.5, 1, 1.5],
                "0": [1/3, 2/3, 1],
                "1": [1/3, 640/currentDocWidth, 1],
                "2": [320/currentDocWidth, 640/currentDocWidth, 640*1.5/currentDocWidth]
            };
            for (var i = 0; i < dpis.length; i++) {
                var m = (currentDocWidth == 1242)? Export.isX3S.toString() : "640";
                var item = export_types[m];
                if (Export.iosDpi[dpis[i]] == 1) {
                    // 恢复到初始
                    if (newDoc.historyStates.length > 1) {
                        newDoc.activeHistoryState = newDoc.historyStates[2];
                    }

                    // 缩放
                    // 形状图层
                    if (layerKind != LayerKind.NORMAL) {
                        if (item[i] != 1) {
                            Export.resizeImage(newDoc.width.value * item[i]);
                            CCLib.alignEdge();
                        }
                    }

                    // 裁切
                    newDoc.trim(TrimType.TRANSPARENT);

                    // 普通图层
                    if (layerKind == LayerKind.NORMAL) {
                        if (item[i] != 1) {
                            Export.resizeImage(newDoc.width.value * item[i]);
                        }
                    }

                    // 选区切图
                    if (hasSelection) {
                        console_debug(s_arr);
                        newDoc.resizeCanvas(s_arr[2]*item[i], s_arr[3]*item[i], AnchorPosition.TOPLEFT);
                        newDoc.activeLayer.translate(s_arr[4]*item[i], s_arr[5]*item[i]);
                    } else if (isFixedSize) {
                        // 设置固定画布
                        var f =  fixed_size_types[m];
                        newDoc.resizeCanvas(Export.fixedWidth*f[i], Export.fixedHeight*f[i], AnchorPosition.MIDDLECENTER);
                    }
                    Export.saveImage(newDoc, Export.savePath.absoluteURI, currentLayerName + ((i==0)? "" : suffixs[i]));

                }
            };
        }

        // android
        if (Export.platform == $.Constants.ANDROID) {
            if (Export.isNinePatch == 1) {      // 画点9图
                var folder = new Folder(Export.savePath.absoluteURI + '/9patch');
                if (!folder.exists) {
                    folder.create();
                }
                newDoc.trim(TrimType.TRANSPARENT);
                Export.drawNinePathLines(newDoc);
                currentLayerName = currentLayerName + '.9';
                Export.saveImage(newDoc, folder.absoluteURI, currentLayerName);
                Export.isNinePatch = 0;
            } else {
                if (Export.isCustomDpi == 1) {
                    var isFixedSize = (Export.fixedWidth > 0 && Export.fixedHeight > 0);
                    var arr = ['xhdpi','xxhdpi', 'hdpi', 'mdpi', 'ldpi'];
                    var base = (currentDocWidth > 720)? Export.customDpi['xxhdpi'] : Export.customDpi['xhdpi'];
                    //var xhdpi = Export.customDpi['xhdpi'];
                    if (base != 0) {
                        for (var m in arr) {
                            if (typeof arr[m] != "string") { break; }
                            var i = Export.customDpi[arr[m]];
                            if (i != 0 && Export.dpi[arr[m]] == 1) {
                                var dpiFolder = new Folder(Export.savePath.absoluteURI + '/drawable-' + arr[m]);
                                if (!dpiFolder.exists) {
                                    dpiFolder.create();
                                }
                                if (newDoc.historyStates.length > 1) {
                                    newDoc.activeHistoryState = newDoc.historyStates[2];
                                }
                                var rate = i/base;

                                // 裁切
								newDoc.trim(TrimType.TRANSPARENT);
                                if (i != base) {
                                    Export.resizeImage(parseInt(newDoc.width) * rate);
                                }
                                CCLib.alignEdge();

                                // 选区切图
                                if (hasSelection) {
                                    newDoc.resizeCanvas(s_arr[2]*rate, s_arr[3]*rate, AnchorPosition.TOPLEFT);
                                    newDoc.activeLayer.translate(s_arr[4]*rate, s_arr[5]*rate);
                                } else if (isFixedSize) {
                                    // 设置固定画布
                                    newDoc.resizeCanvas(Export.fixedWidth * rate, Export.fixedHeight * rate, AnchorPosition.MIDDLECENTER);
                                }
								Export.saveImage(newDoc, dpiFolder.absoluteURI, currentLayerName);
                            }
                        }
                    }
                } else {
                    var isFixedSize = (Export.fixedWidth > 0 && Export.fixedHeight > 0);
                    var arr = ['xxhdpi','xhdpi','hdpi', 'mdpi', 'ldpi'];
                    for (var i=0; i<arr.length; i++) {
                        var key = "720";
                        if (currentDocWidth == 1080 || currentDocHeight == 1080) {
                            key = "1080";
                        }
                        var item = $.Constants.ANDROID_EXPORT_TYPE[key];
                        if (Export.dpi[arr[i]] == 1) {
                            var dpiFolder = new Folder(Export.savePath.absoluteURI + '/drawable-' + arr[i]);
                            if (!dpiFolder.exists) {
                                dpiFolder.create();
                            }

                            // 恢复到初始
                            if (newDoc.historyStates.length > 1) {
                                newDoc.activeHistoryState = newDoc.historyStates[2];
                            }

                            // 缩放
                            if (item[i] != 1) {
                                Export.resizeImage(newDoc.width.value * item[i]);
                                CCLib.alignEdge();
                            }

                            // 裁切
                            newDoc.trim(TrimType.TRANSPARENT);
                            // 选区切图
                            if (hasSelection) {
                                newDoc.resizeCanvas(s_arr[2]*item[i], s_arr[3]*item[i], AnchorPosition.TOPLEFT);
                                newDoc.activeLayer.translate(s_arr[4]*item[i], s_arr[5]*item[i]);
                            } else if (isFixedSize) {
                                // 设置固定画布
                                newDoc.resizeCanvas(Export.fixedWidth * item[i], Export.fixedHeight *item[i], AnchorPosition.MIDDLECENTER);
                            }
                            Export.saveImage(newDoc, dpiFolder.absoluteURI, currentLayerName);
                        }
                    }
                }
            }
        }


        // pc
        if (Export.platform == $.Constants.PC) {
            var isFixedSize = (Export.fixedWidth > 0 && Export.fixedHeight > 0);
            newDoc.trim(TrimType.TRANSPARENT);
            // 选区切图
            if (hasSelection) {
                newDoc.resizeCanvas(s_arr[2], s_arr[3], AnchorPosition.TOPLEFT);
                newDoc.activeLayer.translate(s_arr[4], s_arr[5]);
            } else if (isFixedSize) {
                // 设置固定画布
                newDoc.resizeCanvas(Export.fixedWidth, Export.fixedHeight, AnchorPosition.MIDDLECENTER);
            }
            if (Export.imageResize != 100 && !isFixedSize) {
				Export.resizeImage(parseInt(newDoc.width) *(Export.imageResize*1.0/100));
                CCLib.alignEdge();
            }
			Export.advanceSaveImage(newDoc, Export.savePath.absoluteURI, currentLayerName);
        }

        // 关闭新窗口
        newDoc.close(SaveOptions.DONOTSAVECHANGES);
        app.activeDocument = currentDoc;

        app.preferences.rulerUnits = originalRulerUnits;
        app.preferences.typeUnits = originalTypeUnits;

        if (callback != null) {
            callback();
        }


    } catch (e) {
        console_error($.fileName, $.line, e);
    }
};

/**
 * 判断是否是可以输出的图层
 */
Export.isValidLayer = function(layer) {
    if (layer.kind == undefined) {  // 图层组
        if (layer.layers.length == 0) {
            return false;
        }
        return layer.visible;
    }

    switch(layer.kind) {
        case LayerKind.NORMAL:			// 普通图层
        case LayerKind.TEXT:			// 文字图层
        case LayerKind.SOLIDFILL:		// 形状图层
        case LayerKind.GRADIENTFILL:	// 渐变填充图层
        case LayerKind.PATTERNFILL:		// 图案填充
        case LayerKind.SMARTOBJECT:     // 智能对象
            if (layer.kind != LayerKind.TEXT) {
                // 非文本图层，如果被锁定了，也不弄
                if (layer.pixelsLocked || layer.positionLocked || layer.isBackgroundLayer) {
                    return false;
                }
            }
            if (layer.name == '__cutterman_reserved') {
                return false;
            }
            if (CCLib.isEmptyLayer(layer)) {
                return false;
            }
            if (!layer.visible) {
                return false;
            }
            return true;
    }
    return false;
};


/**
 * 输出图片到指定位置
 * @doc     文档对象
 * @path    保存路径
 * @filename    文件名
 */
Export.saveImage = function(doc, path, filename) {
    try {
        var options = new ExportOptionsSaveForWeb();
        options.format = SaveDocumentType.PNG;
        options.PNG8 = false;
        options.quality = 100;
        var file = new File(path + "/" + filename + ".png");
        if (file.exists && Export.sameName == 1) {
            var suffix = $.Constants.FILE_SUFFIX.shift();
            file = new File(path + "/" + filename + "_" + suffix + ".png");
        }
        doc.exportDocument(file, ExportType.SAVEFORWEB, options);
    } catch (e) {
        console_error($.fileName, $.line, e);
    }
};

Export.advanceSaveImage = function(doc, path, filename) {
    var options = new ExportOptionsSaveForWeb();
    var formats = [SaveDocumentType.PNG, SaveDocumentType.JPEG, SaveDocumentType.COMPUSERVEGIF];
    options.format = formats[Export.imageType];
    var suffix = "";
    if (Export.imageType == 0) {
        options.PNG8 = (Export.imageOptim == 24)? false : true;
        options.quality = 100;
        suffix = ".png";
    }
    if (Export.imageType == 1) {
        options.quality = Export.imageOptim;
        suffix = ".jpg";
    }
    if (Export.imageType == 2) {
        options.colors = Export.imageOptim;	// 颜色值
        options.PNG8 = true;
        options.colorReduction = ColorReductionType.SELECTIVE;	// 可选择
        options.quality = 0;			// 这里设置0是为了解决lossy设置不生效的bug
        options.dither = Dither.NONE;	// 无仿色
        suffix = ".gif";
    }
    var file = new File(path + "/" + filename + suffix);
    if (file.exists && Export.sameName == 1) {
        var sf = $.Constants.FILE_SUFFIX.shift();
        file = new File(path + "/" + filename + "_" + sf + suffix);
    }
    doc.exportDocument(file, ExportType.SAVEFORWEB, options);
}


/**
 * 缩放图片大小
 */
Export.resizeImage = function(width)
{
    var action = new ActionDescriptor();
    action.putUnitDouble(app.charIDToTypeID("Wdth"), app.charIDToTypeID("#Pxl"), width);
    action.putBoolean(app.stringIDToTypeID("scaleStyles"), true);
    action.putBoolean(app.charIDToTypeID("CnsP"), true);
    action.putEnumerated(app.charIDToTypeID("Intr"), app.charIDToTypeID("Intp"), app.charIDToTypeID('Blnr'));
    app.executeAction(app.charIDToTypeID("ImgS"), action, DialogModes.NO);
};

/**
 * Android画点9图的线
 */
Export.drawNinePathLines = function(doc)
{
    try {
        var w = parseInt(doc.width);
        var h = parseInt(doc.height);
        doc.resizeCanvas(w+2, h+2, AnchorPosition.MIDDLECENTER);
        var layer = doc.artLayers.add();
        doc.activeLayer = layer;

        CCLib.changeFrontColor(0, 0, 0);
        CCLib.selectASelection(w+1, 1, w+2, h+1);
        CCLib.fillColor(w+1, 0);
        CCLib.deselectSelection();

        CCLib.selectASelection(1, h+1, w+1, h+2);
        CCLib.fillColor(0, h+1);
        CCLib.deselectSelection();

        CCLib.selectASelection(0, (h+2)/2, 1, (h+2)/2 + 1);
        CCLib.fillColor(0, (h+2)/2);
        CCLib.deselectSelection();

        CCLib.selectASelection((w+2)/2, 0, (w+2)/2 +1, 1);
        CCLib.fillColor((w+2)/2, 0);
        CCLib.deselectSelection();
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}


/**
 * 设置输出路径
 * @path
 */
Export.setSavePath = function(path) {
    try {
        path = (path == undefined)? Folder.desktop.absoluteURI : path;
        Export.savePath = new Folder(path);
    } catch (e) {
        console_error($.fileName, $.line, e);
        Export.savePath = new Folder(Folder.desktop.absoluteURI);
    }
};



/**
 * 设置目标平台
 */
Export.setPlatform = function(v) {
    Export.platform = parseInt(v);
}

/**
 * 设置固定宽和高输出
 */
Export.setFixedSize = function(w, h) {
    w = (w == undefined)? 0 : w;
    h = (h == undefined)? 0 : h;
    Export.fixedWidth = parseInt(w);
    Export.fixedHeight = parseInt(h);
};

/**
 * 设置dpi
 * @dpi  是一个json字符串
 */
Export.setDPI = function(key, value) {
    Export.dpi[key] = value;
};

Export.setIOSDPI = function(key, value) {
    Export.iosDpi[key] = value;
};

Export.setImageType = function(type) {
    Export.imageType = type;
};

Export.setImageOptim = function(value) {
    Export.imageOptim = value;
};

Export.setImageResize = function(value) {
    Export.imageResize = value;
};

Export.setExportType = function(value) {
    Export.multiMerge = value;
};

Export.setSuffix = function(value) {
    Export.suffix = value;
};

Export.setSameName = function(value) {
    Export.sameName = value;
};

Export.applyCustomDPI = function(value) {
    Export.isCustomDpi = value;
};

Export.setCustomDPI = function(key, value) {
    Export.customDpi[key] = value;
};

Export.setX3S = function(value) {
    Export.isX3S = value;
};

try {
    // 初始化配置
    var filename = Folder.userData + '/.cm.2_4.conf';
    var file = new File(filename);
    if (file.exists) {
        if (file.open('r')) {
            var data = file.read();
            if (data != null) {
                var json = eval('('+data+')');
                Export.platform = parseInt(json.app.tab);
                Export.dpi.xxhdpi = parseInt(json.app.xxhdpi);
                Export.dpi.xhdpi = parseInt(json.app.xhdpi);
                Export.dpi.hdpi = parseInt(json.app.hdpi);
                Export.dpi.mdpi = parseInt(json.app.mdpi);
                Export.dpi.ldpi = parseInt(json.app.ldpi);
                Export.iosDpi.x1 = parseInt(json.app.x1);
                Export.iosDpi.x2 = parseInt(json.app.x2);
                Export.iosDpi.x3 = parseInt(json.app.x3);
                Export.setSavePath(json.app.path);
                Export.isCustomDpi = parseInt(json.app.customDpi);
                Export.isX3S = parseInt(json.app.x3s);
                Export.multiMerge = parseInt(json.app.merge);
                Export.sameName = parseInt(json.app.sameName);
                Export.setSuffix(json.app.suffix);
            }
            file.close();
        }
    } else {
        //alert('file not exists');
    }
} catch(e) {
}


