/* vim: set et sw=4 ts=4 sts=4 fdm=marker ff=unix fenc=utf8 nobomb: */

/**
 * library.js
 * 标准库，提供了很多基本接口
 * 此库从Xbytor's stdlib.js参考而来
 * http://ps-scripts.cvs.sourceforge.net/ps-scripts/xtools/xlib/stdlib.js?view=log
 *
 * @author xiaoqiang
 * @mail   qiang0902@126.com
 * @2014-08-04
 */

cTID = function(s) { return cTID[s] || cTID[s] = app.charIDToTypeID(s); };
sTID = function(s) { return sTID[s] || sTID[s] = app.stringIDToTypeID(s); };

charIDToTypeID = function(s) { return app.charIDToTypeID(s); }
stringIDToTypeID = function(s) { return app.stringIDToTypeID(s); }

CCLib = function() {};
CCLib.VERSION = "1.0";


/**
 * 获取选中的图层ID  返回单个、多个数字
 */ 
CCLib.getSelectedLayersIdx = function() {
    var selectedLayers = new Array();
    var ref = new ActionReference();
    ref.putEnumerated(cTID('Dcmn'), cTID('Ordn'), cTID('Trgt'));
    var desc = app.executeActionGet(ref);
    if (desc.hasKey(sTID('targetLayers'))) {
        desc = desc.getList(sTID('targetLayers'));
        var c = desc.count
            var selectedLayers = new Array();
        for (var i = 0; i < c; i++) {
            try {
                app.activeDocument.backgroundLayer;
                selectedLayers.push(desc.getReference(i).getIndex());
            } catch(e) {
                selectedLayers.push(desc.getReference(i).getIndex() + 1);
            }
        }
    } else {
        var ref = new ActionReference();
        ref.putProperty(cTID('Prpr'), cTID('ItmI'));
        ref.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
        try {
            app.activeDocument.backgroundLayer;
            selectedLayers.push(app.executeActionGet(ref).getInteger(cTID('ItmI')) - 1);
        } catch(e) {
            selectedLayers.push(app.executeActionGet(ref).getInteger(cTID('ItmI')));
        }
    }
    return selectedLayers;
}

/**
 * 根据某个图层的索引选中该图层
 * @index  图层索引
 */
CCLib.selectLayerByID = function(index) {
    var ref = new ActionReference();
    ref.putIndex(cTID("Lyr "), index);
    var desc = new ActionDescriptor();
    desc.putReference(cTID("null"), ref);
    //if (add) desc.putEnumerated(sTID("selectionModifier"), sTID("selectionModifierType"), sTID("selection"));
    desc.putBoolean(cTID("MkVs"), false);
    try {
        app.executeAction(cTID("slct"), desc, DialogModes.NO);
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

/**
 * 对齐边缘功能
 */
CCLib.alignEdge = function() {
    var idsetd = cTID( "setd" );
    var desc42 = new ActionDescriptor();
    var idnull = cTID( "null" );
    var ref31 = new ActionReference();
    var idLyr = cTID( "Lyr " );
    var idOrdn = cTID( "Ordn" );
    var idTrgt = cTID( "Trgt" );
    ref31.putEnumerated( idLyr, idOrdn, idTrgt );
    desc42.putReference( idnull, ref31 );
    var idT = cTID( "T   " );
    var desc43 = new ActionDescriptor();
    var iduseAlignedRendering = sTID( "useAlignedRendering" );
    desc43.putBoolean( iduseAlignedRendering, true );
    var idLyr = cTID( "Lyr " );
    desc42.putObject( idT, idLyr, desc43 );
    try {
        executeAction( idsetd, desc42, DialogModes.NO );
    } catch (e) {
        console_error($.fileName, $.line, e);
    }
};

/**
 * 修改前景色
 */
CCLib.changeFrontColor = function(r, g, b) {
    var idsetd = cTID( "setd" );
    var desc15 = new ActionDescriptor();
    var idnull = cTID( "null" );
    var ref7 = new ActionReference();
    var idClr = cTID( "Clr " );
    var idFrgC = cTID( "FrgC" );
    ref7.putProperty( idClr, idFrgC );
    desc15.putReference( idnull, ref7 );
    var idT = cTID( "T   " );
    var desc16 = new ActionDescriptor();
    var idRd = cTID( "Rd  " );
    desc16.putDouble( idRd, r );
    var idGrn = cTID( "Grn " );
    desc16.putDouble( idGrn, g );
    var idBl = cTID( "Bl  " );
    desc16.putDouble( idBl, b );
    var idRGBC = cTID( "RGBC" );
    desc15.putObject( idT, idRGBC, desc16 );
    var idSrce = cTID( "Srce" );
    desc15.putString( idSrce, "photoshopPicker" );
    try {
        executeAction( idsetd, desc15, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
};

// 选择一个区域
CCLib.selectASelection = function(left, top, right, bottom)
{
    var idsetd = cTID( "setd" );
    var desc22 = new ActionDescriptor();
    var idnull = cTID( "null" );
    var ref13 = new ActionReference();
    var idChnl = cTID( "Chnl" );
    var idfsel = cTID( "fsel" );
    ref13.putProperty( idChnl, idfsel );
    desc22.putReference( idnull, ref13 );
    var idT = cTID( "T   " );
    var desc23 = new ActionDescriptor();
    var idTop = cTID( "Top " );
    var idPxl = cTID( "#Pxl" );
    desc23.putUnitDouble( idTop, idPxl, top );
    var idLeft = cTID( "Left" );
    var idPxl = cTID( "#Pxl" );
    desc23.putUnitDouble( idLeft, idPxl, left );
    var idBtom = cTID( "Btom" );
    var idPxl = cTID( "#Pxl" );
    desc23.putUnitDouble( idBtom, idPxl, bottom );
    var idRght = cTID( "Rght" );
    var idPxl = cTID( "#Pxl" );
    desc23.putUnitDouble( idRght, idPxl, right );
    var idRctn = cTID( "Rctn" );
    desc22.putObject( idT, idRctn, desc23 );
    try {
        executeAction( idsetd, desc22, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

// 用前景色填充
CCLib.fillColor = function(x, y)
{
    var idFl = cTID( "Fl  " );
    var desc60 = new ActionDescriptor();
    var idFrom = cTID( "From" );
    var desc61 = new ActionDescriptor();
    var idHrzn = cTID( "Hrzn" );
    var idPxl = cTID( "#Pxl" );
    desc61.putUnitDouble( idHrzn, idPxl, x );
    var idVrtc = cTID( "Vrtc" );
    var idPxl = cTID( "#Pxl" );
    desc61.putUnitDouble( idVrtc, idPxl, y );
    var idPnt = cTID( "Pnt " );
    desc60.putObject( idFrom, idPnt, desc61 );
    var idTlrn = cTID( "Tlrn" );
    desc60.putInteger( idTlrn, 32 );
    var idAntA = cTID( "AntA" );
    desc60.putBoolean( idAntA, true );
    var idUsng = cTID( "Usng" );
    var idFlCn = cTID( "FlCn" );
    var idFrgC = cTID( "FrgC" );
    desc60.putEnumerated( idUsng, idFlCn, idFrgC );
    var idCntg = cTID( "Cntg" );
    desc60.putBoolean( idCntg, false );
    try {
        executeAction( idFl, desc60, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

// 取消选择
CCLib.deselectSelection = function()
{
    var idsetd = cTID( "setd" );
    var desc16 = new ActionDescriptor();
    var idnull = cTID( "null" );
    var ref9 = new ActionReference();
    var idChnl = cTID( "Chnl" );
    var idfsel = cTID( "fsel" );
    ref9.putProperty( idChnl, idfsel );
    desc16.putReference( idnull, ref9 );
    var idT = cTID( "T   " );
    var idOrdn = cTID( "Ordn" );
    var idNone = cTID( "None" );
    desc16.putEnumerated( idT, idOrdn, idNone );
    try {
        executeAction( idsetd, desc16, DialogModes.NO );
    } catch (e) {
        console_error($.fileName, $.line, e);
    }
}

// 合并选中的图层
CCLib.mergeSelectedLayers = function() {
    var idMrgtwo = cTID( "Mrg2" );
    var desc7 = new ActionDescriptor();
    try {
        executeAction( idMrgtwo, desc7, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

// 合并可见的图层
CCLib.mergeVisibleLayers = function() {
    var idMrgtwo = cTID( "MrgV" );
    var desc7 = new ActionDescriptor();
    try {
        executeAction( idMrgtwo, desc7, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

// 删除当前的历史
CCLib.deleteCurrentHistroyState = function() {
    var idDlt = charIDToTypeID( "Dlt " );
    var desc8 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref5 = new ActionReference();
    var idHstS = charIDToTypeID( "HstS" );
    var idCrnH = charIDToTypeID( "CrnH" );
    ref5.putProperty( idHstS, idCrnH );
    desc8.putReference( idnull, ref5 );
    try {
        executeAction( idDlt, desc8, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

// 复制多个图层到一个新的文档
CCLib.duplicateLayers = function() {
    var idMk = charIDToTypeID( "Mk  " );
    var desc11 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref8 = new ActionReference();
    var idDcmn = charIDToTypeID( "Dcmn" );
    ref8.putClass( idDcmn );
    desc11.putReference( idnull, ref8 );
    var idUsng = charIDToTypeID( "Usng" );
    var ref9 = new ActionReference();
    var idLyr = charIDToTypeID( "Lyr " );
    var idOrdn = charIDToTypeID( "Ordn" );
    var idTrgt = charIDToTypeID( "Trgt" );
    ref9.putEnumerated( idLyr, idOrdn, idTrgt );
    desc11.putReference( idUsng, ref9 );
    var idVrsn = charIDToTypeID( "Vrsn" );
    desc11.putInteger( idVrsn, 5 );
    try {
        executeAction( idMk, desc11, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

// 是否是空图层
CCLib.isEmptyLayer = function(layer) {
    return (parseInt(layer.bounds[0]) == 0 &&
            parseInt(layer.bounds[1]) == 0 &&
            parseInt(layer.bounds[2]) == 0 &&
            parseInt(layer.bounds[3]) == 0);
}

// 设置全局光的角度
CCLib.applyGlobalLight = function(angle, altitude)
{
    var idsetd = charIDToTypeID( "setd" );
    var desc50 = new ActionDescriptor();
    var idnull = charIDToTypeID( "null" );
    var ref22 = new ActionReference();
    var idPrpr = charIDToTypeID( "Prpr" );
    var idgblA = charIDToTypeID( "gblA" );
    ref22.putProperty( idPrpr, idgblA );
    var idDcmn = charIDToTypeID( "Dcmn" );
    var idOrdn = charIDToTypeID( "Ordn" );
    var idTrgt = charIDToTypeID( "Trgt" );
    ref22.putEnumerated( idDcmn, idOrdn, idTrgt );
    desc50.putReference( idnull, ref22 );
    var idT = charIDToTypeID( "T   " );
    var desc51 = new ActionDescriptor();
    var idgagl = charIDToTypeID( "gagl" );
    var idAng = charIDToTypeID( "#Ang" );
    desc51.putUnitDouble( idgagl, idAng, angle );
    var idglobalAltitude = stringIDToTypeID( "globalAltitude" );
    var idAng = charIDToTypeID( "#Ang" );
    desc51.putUnitDouble( idglobalAltitude, idAng, altitude );
    var idgblA = charIDToTypeID( "gblA" );
    desc50.putObject( idT, idgblA, desc51 );
    try {
        executeAction( idsetd, desc50, DialogModes.NO );
    } catch(e) {
        console_error($.fileName, $.line, e);
    }
}

// 获取当前全局光的角度
CCLib.getGlobalLightAngle = function()
{
    var ref = new ActionReference();
    ref.putEnumerated( charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt") );
    var angle = executeActionGet(ref).getInteger(stringIDToTypeID('globalAngle'));
    return angle;
}
