/* vim: set et sw=4 ts=4 sts=4 fdm=marker ff=unix fenc=utf8 nobomb: */

/**
 * filename.js
 *
 * @author xiaoqiang
 * @mail   qiang0902@126.com
 * @date
 */

$.Constants = {
    IOS: 1,
    ANDROID: 2,
    PC: 3,
    IOS_RETINA_SUFFIX: '@2x',
    ANDROID_EXPORT_TYPE: {
        "720": [3/2, 1, 3/4, 1/2, 3/8],
        "1080": [1, 2/3, 1/2, 1/3, 1/4]
    },
    IOS_EXPORT_TYPE: {
        "640": [0.5, 1, 1.5],
        "1080": [1/3, 2/3, 1],
    },
    FILE_SUFFIX: ['1', '2', '3','4','5','6','7','8','9']
};
