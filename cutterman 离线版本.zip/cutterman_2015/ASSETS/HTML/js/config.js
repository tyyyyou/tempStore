/* vim: set et sw=4 ts=4 sts=4 fdm=marker ff=unix fenc=utf8 nobomb: */

/**
 * filename.js
 *
 * @author xiaoqiang
 * @mail   qiang0902@126.com
 * @date
 */

var CC = CC || new CSInterface();
var CEP = window.cep;

var Config = {
    version: 1,
    name: '.cm.2_4.conf',
    data: {     
        user: {
                  email: '',
                  uid: '',
                  name: '',
                  avatar: '',
                  emailValidate: 0,
                  register_time: 0
              },
        app: {
                 version: {
                              code: 240,
                              str: "2.6.0"
                          }, 
                 tab: 2,     
                 xxhdpi: 0,         
                 xhdpi: 1,
                 hdpi: 1,
                 mdpi: 0,
                 ldpi: 0,
                 x1: 0,     
                 x2: 1,
                 x3: 1,
                 path: '',          
                 customDpi: 0,
                 merge: 0,
                 x3s: 0,
                 sameName: 0,       
                 suffix: '@2x'
             }
    }
};



Config.init = function() {
    var extensionPath = CC.getSystemPath(SystemPath.USER_DATA);
    var filename = extensionPath + '/' + Config.name;
    var result = CEP.fs.readFile(filename);
    if (result.err == 0) {  
        Config.data = JSON.parse(result.data);
    } else {
        var w = CEP.fs.writeFile(filename, JSON.stringify(Config.data));
        if (w.err == 0) {
        } else {
        }
    }
};

Config.user = function() {
    if (arguments.length == 0) {
        return Config.data.user;
    } else if (arguments.length == 1) {
        return Config.data.user[arguments[0]];
    } else {
        Config.data.user[arguments[0]] = arguments[1];
        Config.save();
    }
};

Config.app = function() {
    if (arguments.length == 0) {
        return Config.data.app;
    } else if (arguments.length == 1) {
        return Config.data.app[arguments[0]];
    } else {
        Config.data.app[arguments[0]] = arguments[1];
        Config.save();
    }
};

Config.save = function() {
    var extensionPath = CC.getSystemPath(SystemPath.USER_DATA);
    var filename = extensionPath + '/' + Config.name;
    var w = CEP.fs.writeFile(filename, JSON.stringify(Config.data));
    if (w.err == 0) {
    } else {
    }
};



var HOST = 'http://www.cutterman.cn';
var URL = {
    REGISTER : HOST + '/user/register',
    LOGIN: HOST + '/user/login',
    CHECK_VALIDATE: HOST + '/user/checkemail',
    RESEND: HOST + '/user/resendemail',
    CHECK_UPDATE: HOST + '/app/check_update'
};



