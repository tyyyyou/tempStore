/* vim: set et sw=4 ts=4 sts=4 fdm=marker ff=unix fenc=utf8 nobomb: */

/**
 * filename.js
 *
 * @author xiaoqiang
 * @mail   qiang0902@126.com
 * @2014-10-17
 */

var ver = "2.6.0";

function initial() {

    var platform = 2;

    $('.tab button').click(function() {
        $('.tab div').removeClass('active');
        $(this).parent().addClass('active');
        platform = parseInt($(this).attr('platform'));
        Config.app('tab', platform);
        tabSwitch(platform);
        CC.evalScript('Export.setPlatform('+ platform +')');

        var tabs = ['ios-options', 'android-options', 'web-options'];
        var w = $('#' + tabs[platform-1]).find('.fixed-width').val();
        var h = $('#' + tabs[platform-1]).find('.fixed-height').val();
        w = (w == '')? 0 : w;
        h = (h == '')? 0 : h;
        CC.evalScript('Export.setFixedSize('+ w +','+ h +')');

    });

    $('#merge-switcher').change(function() {
        var checked = $(this).is(':checked');
        var v = checked? 1 : 0;
        Config.app('merge', v);
        CC.evalScript('Export.setExportType('+ v  +')');
    });

    $('.fixed-size input').blur(function() {
        var p = $(this).parent('.fixed-size');
        var w = parseInt($(p).children('.fixed-width').val());
        var h = parseInt($(p).children('.fixed-height').val());
        console.log('w:' + w + ", h: " + h);
        CC.evalScript('Export.setFixedSize('+ w +','+ h +')');
    });

    $('#path').click(function() {
        pathSelect();
    });

    $('.ios-dpi-list button').click(function() {
        $(this).parent().toggleClass('active');
        var key = $(this).attr('key');
        var value = $(this).parent().hasClass('active')? 1 : 0;
        Config.app(key, value);
        CC.evalScript('Export.setIOSDPI("'+ key +'",'+ value +')');
    });

    $('.ios-3x-list button').click(function() {
        $('.ios-3x-list li').removeClass('active');
        $(this).parent().addClass('active');
        var v = $(this).val();
        Config.app('x3s', v);
        CC.evalScript('Export.setX3S('+ v  +')');
    });

    $('.android-dpi-list button').click(function() {
        $(this).parent().toggleClass('active');
        var key = $(this).text().toLowerCase();
        var value = $(this).parent().hasClass('active')? 1 : 0;
        Config.app(key, value);
        CC.evalScript('Export.setDPI("'+ key +'",'+ value +')');
    });

    $('.format-list button').click(function() {
        $('.format-list li').removeClass('active');
        $(this).parent().addClass('active');
        $('.quality-list ul').hide();
        var c = $(this).attr('target');
        $('.'+c).show();
        
        var v = $(this).val();

        var arr = [24, 100, 256];
        CC.evalScript('Export.setImageOptim('+ arr[v] +')');

        if (c != 'jpg-list') {
            $('.' +c).children().removeClass('active');
            $('.'+c).children().eq(0).addClass('active');
        }

    });

    $('.png-list button').click(function() {
        $('.png-list li').removeClass('active');
        $(this).parent().toggleClass('active');
        CC.evalScript('Export.setImageOptim('+ $(this).val() +')');
    });

    $('.gif-list button').click(function() {
        $('.gif-list li').removeClass('active');
        $(this).parent().toggleClass('active');
        CC.evalScript('Export.setImageOptim('+ $(this).val() +')');
    });

    $('.jpg-list input').blur(function() {
        CC.evalScript('Export.setImageOptim('+ $(this).val() +')');
    });

    $('.format-list button').click(function() {
        var v = $(this).attr('value');
        CC.evalScript('Export.setImageType('+ v +')');
    });

    $('.png-list button').click(function() {
        var v = $(this).attr('value');
        CC.evalScript('Export.setImageOptim('+ v +')');
    });

    $('.scale input').blur(function() {
        var v = $(this).val();
        CC.evalScript('Export.setImageResize('+v+')');
    });

    $('#setting').click(function() { 
        $('#main-panel').hide();
        $('#setting-panel').show();
        if (platform == 2) {
            $('#custom-dpi').show();
            $("#recommend").hide();
        } else {
            $('#custom-dpi').hide();
            $("#recommend").show();
        }
    });

    $('#back-icon').click(function() {
        $('#main-panel').show();
        $('#setting-panel').hide();
    });

    $('.setting-common button').click(function() {
        $('.setting-common b').removeClass('active');
        $(this).parent().addClass('active');
        var v = $(this).val();
        Config.app('sameName', v);
        CC.evalScript('Export.setSameName('+v+')');
    });

    $('#custom-dpi-switch').change(function() {
        var checked = $(this).is(':checked');
        var v = checked? 1 : 0;
        Config.app('customDpi', v);
        CC.evalScript('Export.applyCustomDPI('+ v  +')');
    });

    $('#recommend a').click(function(e) {
        e.preventDefault();
        openURL($(this).attr("url"));
    });

    $('#export-btn').click(function(){ exportLayers(); });
    $('#export-nine-patch').click(function() { exportNinePatch(); });


    $('.android-custom-dpi input').blur(function() {
        var key = $(this).attr("name");
        var value = $(this).val();
        localStorage.setItem(key, value);
        CC.evalScript('Export.setCustomDPI("'+ key  +'", '+value+')');
    });

};

function init() {
    Config.init();  

    $('#main-panel').show();

    configurePanel();

    initial();

    var evt = new CSEvent('com.adobe.PhotoshopPersistent', "APPLICATION");
    evt.extensionId = "Cutterman_offline";
    CC.dispatchEvent(evt);

}


function configurePanel() {
    var tab = parseInt(Config.app('tab'));
    $('.tab').children().removeClass('active');
    $('.tab').children().eq(tab-1).addClass('active');
    tabSwitch(tab);

    var merge = Config.app('merge');
    if (merge == 1) {
        $('#merge-switcher').attr('checked', true);
    }

    var path = Config.app('path');
    path = (path == '')? 'path/to/output' : path;
    $('#path').text(path.substr(path.length - 14, path.length));

    $('.ios-dpi-list li').each(function() {
        var key = $(this).attr('target');
        if (parseInt(Config.app(key)) == 1) {
            $(this).addClass('active');
        } else {
            $(this).removeClass('active');
        }
    });

    $('.android-dpi-list li').each(function() {
        var key = $(this).children().eq(0).text().toLowerCase();
        if (parseInt(Config.app(key)) == 1) {
            $(this).addClass('active');
        } else {
            $(this).removeClass('active');
        }
    });

    var sameName = Config.app('sameName');
    $('.setting-common b').each(function(idx, item) {
        if (idx == parseInt(sameName)) {
            $(item).addClass('active');
        } else {
            $(item).removeClass('active');
        }
    });

    var customDpi = Config.app('customDpi');
    if (customDpi == 1) {
        $('#custom-dpi-switch').attr('checked', true);
    }

    var defaultV = {
        "xxhdpi": 1080,
        "xhdpi": 720,
        "hdpi" : 480,
        "mdpi": 320,
        "ldpi" : 240
    };
    $('.android-custom-dpi input').each(function(idx, item) {
        var key = $(item).attr("name");
        var v = localStorage.getItem(key);
        var nv = (v==null)? defaultV[key] : v;
        $(item).val(nv);
    });

    var app = Config.app();
    $('#version').text('v ' + ver);
    $('#version').click(function() {
        location.reload(true);
    });


}

function tabSwitch(platform) {
    switch(platform) {
        case 1:
            $('.export-btns').removeClass('android-panel');
            $('#ios-options').show();
            $('#android-options').hide();
            $('#web-options').hide();
            break;
        case 2:
            $('.export-btns').addClass('android-panel');
            $('#ios-options').hide();
            $('#android-options').show();
            $('#web-options').hide();
            break;
        case 3:
            $('.export-btns').removeClass('android-panel');
            $('#ios-options').hide();
            $('#android-options').hide();
            $('#web-options').show();
            break;
    }

}


function exportLayers() {
    CC.evalScript('Export.exportSelectLayer()', function(result) {
        var email = Config.user('email');
        var uid = Config.user('uid');
        if (email != '' && uid != '' && parseInt(result) > 0) {
            $.post('http://www.cutterman.cn/rank/submit', {email: email, uid: uid, num: result}, function(result) {

                });
        }
    });
}

function exportNinePatch() {
    CC.evalScript('Export.exportNinePatch()');
}

function pathSelect() {
    try {
        var result = CEP.fs.showOpenDialog(false, true, "please select place to save", null, false);
        if (result.err == 0) {
            var path = result.data[0];
            $('#path').text(path.substr(path.length - 14, path.length));
            Config.app('path', path);
            CC.evalScript('Export.setSavePath("'+ path +'")');
        }
    } catch(e) {

    }
}

init();

