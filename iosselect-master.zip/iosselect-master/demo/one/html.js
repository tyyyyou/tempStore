var data = [
    {'id': '10001', 'value': '<b>工商银行</b><i>ICBC</i>'},
    {'id': '10002', 'value': '<b>农业银行</b><i>ABC</i>'},
];