>描述
```html
    名称：89大促
    需求：陈一帆
    设计：李会梁
    开发：李光全
```

>构建
```html
   pages\UI\SpringAirlines\Views\Activitiesall\Activities664.cshtml
   pages\UI\SpringAirlines\Views\Activitiesall\Activities664.Mobile.cshtml
   pages\UI\SpringAirlines\Controllers\ActivitiesallController.cs
   CdnSite\SpringAirlines\images\Activitiesall\Activities664\*.*
   CdnSite\SpringAirlines\images\Activitiesall\Activities664\m\*.*
   E:\上海SVN\电商-网站\branches\pages\UI\SpringAirlines\Views\Activitiesall
   \\192.168.220.34\d\V4\pages.ch.com\Views\Activitiesall
```

>运行
```html
    npm config set registry https://registry.npm.taobao.org
    npm install
    cd app
    fis3 release -Lwc
    cd ..
    gulp
```
