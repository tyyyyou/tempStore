define("fn-getTravelPros",function(require, exports) {
    var view = require('view');
    var defaults = {
        pageId: 35551, //需覆盖
        lineId: 37675, //需覆盖
        $wrapDom: "", //必传
        isServerTime: true,
        terminalType: "PC",
        maxLen: 0, //非必传，默认接口返回的旅游产品个数
        itemSelector: '', //必传，承载单个旅游产品的直接父级选择器
        myTemplate: function(data){}, //必传，返回值为单个旅游产品的html字符串
        successCallback: '', //非必传，旅游接口请求成功回调
        btnText_done: '已售罄', //产品已售罄时，文字按钮显示
        btnText_notyet: '敬请期待', //产品未开售时，文字按钮显示
        btnText_act: '立即抢购' //产品可购买时，文字按钮显示
    };

    var init = function(conf){
        return new TravelPros(conf);
    };
    function TravelPros(conf){
        this.conf = $.extend({}, defaults, conf);
        this.init();
    }
    TravelPros.prototype.init = function(){
        var _this = this;
        var ajaxUrl = "";
        if(_this.conf.terminalType == "APP"){
            ajaxUrl = "http://trippages.ch.com/activity/ActivityPage/SearchLineByID";
        }else {
            ajaxUrl = "/AirFlights/SearchLineByID";
        }
        $.ajax({
            type: "post",
            url: ajaxUrl,
            data: { "pageId": _this.conf.pageId, "lineId": _this.conf.lineId },
            success: function (data) {
                _this.conf.successCallback && _this.conf.successCallback();
                typeof data == "string" && (data=JSON.parse(data));
                //data={"detailList":[{"Id":"45001","ProductId":"95445","BeginDate":"2018-11-18","EndDate":"2019-08-30","KeyWord":"","RouteName":"【官网专享】成都出发   泰国苏梅岛6日自由行（成都直飞素叻他尼往返含税机票+赠送车船接送机）","Mian":"★白班机直飞苏梅岛素叻他尼，赠车船联运，当天上岛！","Url":"vacation/95445","RecommendPic":"http://media.china-sss.com/pics/gallery/201612/a61883d0-c813-49be-853e-778e294c6c85_201612261749_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"1599","Price":"1599","ActivityPrice":null},{"Id":"44995","ProductId":"40551","BeginDate":"2015-10-10","EndDate":"2017-11-30","KeyWord":"","RouteName":"【6人共减500】日本香川+小豆岛+直岛5日4晚自由行（中心商圈附近酒店+赠栗林公园门票）","Mian":"★高松华盛顿酒店靠近中心商圈瓦町、兵步町，优越地理位置！\n★濑户内海最新鲜的刺身，和牛烧肉比国内便宜好多，米其林三星景区栗林公园，小豆岛浪漫天使之路，直岛草间弥生的大南瓜，安藤忠雄地中美术馆！兵库町，瓦町，药妆店国人少，买到爽！","Url":"vacation/40551","RecommendPic":"http://media.china-sss.com/pics/gallery/201510/e7fbcb8f-1b91-47d4-8476-3bf2d93d19d4_201510161752_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"1499","Price":"1499","ActivityPrice":null},{"Id":"44993","ProductId":"15119","BeginDate":"2015-03-19","EndDate":"2017-09-13","KeyWord":"","RouteName":"【暑期开售】大阪+京都+奈良5日4晚自由行●宿4晚温泉酒店（暑期火爆开班  早去晚回航班）","Mian":"★大阪市区独家天然温泉酒店，入住即可免费泡汤\n★体验独特超级房，大床宽1.4米，小床宽1米\n★女性入住即送小礼包\n★酒店大堂可自行挑选舒适枕头\n★请注意温泉酒店特殊规定：儿童或婴儿同成人收费！单数预订需补房差！\n","Url":"vacation/15119","RecommendPic":"http://media.china-sss.com/pics/gallery/201602/c049a5ad-aea3-4752-b691-db7499590521_201602231233_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"2199","Price":"2199","ActivityPrice":null},{"Id":"44994","ProductId":"37699","BeginDate":"2015-02-17","EndDate":"2017-06-30","KeyWord":"","RouteName":"【暑期热卖】福冈+别府+佐贺6日1晚自由行●宿1晚佐贺JR站附近酒店（回程行李额免费升级至25kg）","Mian":"★最后一晚入住佐贺站前酒店，交通便利，回程不用起早赶飞机\n★推荐鸟栖outlets，距离佐贺、福冈均车程1小时，九州最大的outlets之一\n★福冈药妆、电器、潮流服饰全都能买到\n","Url":"vacation/37699","RecommendPic":"http://media.china-sss.com/pics/gallery/201510/9c195172-6bbb-45a8-a455-ae67940a6912_201510161828_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"1000","Price":"1000","ActivityPrice":null},{"Id":"44992","ProductId":"53656","BeginDate":"2015-08-15","EndDate":"2017-10-31","KeyWord":"","RouteName":"【暑期正热卖】北海道5日1晚自由行（含往返机票+首晚札幌市区酒店住宿）","Mian":"★优质航班解决您的出行之忧\n★仅含首晚酒店住宿，自由安排行程！\n★+200元/人回程行李额升级至25公斤！","Url":"vacation/53656","RecommendPic":"http://media.china-sss.com/pics/gallery/201702/982b7add-2620-4367-8a35-51b626c39b74_201702241355_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"1799","Price":"1799","ActivityPrice":null},{"Id":"44992","ProductId":"53656","BeginDate":"2015-08-15","EndDate":"2017-10-31","KeyWord":"","RouteName":"【暑期正热卖】北海道5日1晚自由行（含往返机票+首晚札幌市区酒店住宿）","Mian":"★优质航班解决您的出行之忧\n★仅含首晚酒店住宿，自由安排行程！\n★+200元/人回程行李额升级至25公斤！","Url":"vacation/53656","RecommendPic":"http://media.china-sss.com/pics/gallery/201702/982b7add-2620-4367-8a35-51b626c39b74_201702241355_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"1799","Price":"1799","ActivityPrice":null}, {"Id":"44992","ProductId":"53656","BeginDate":"2015-08-15","EndDate":"2017-10-31","KeyWord":"","RouteName":"【暑期正热卖】北海道5日1晚自由行（含往返机票+首晚札幌市区酒店住宿）","Mian":"★优质航班解决您的出行之忧\n★仅含首晚酒店住宿，自由安排行程！\n★+200元/人回程行李额升级至25公斤！","Url":"vacation/53656","RecommendPic":"http://media.china-sss.com/pics/gallery/201702/982b7add-2620-4367-8a35-51b626c39b74_201702241355_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"1799","Price":"1799","ActivityPrice":null}, {"Id":"44992","ProductId":"53656","BeginDate":"2015-08-15","EndDate":"2017-10-31","KeyWord":"","RouteName":"【暑期正热卖】北海道5日1晚自由行（含往返机票+首晚札幌市区酒店住宿）","Mian":"★优质航班解决您的出行之忧\n★仅含首晚酒店住宿，自由安排行程！\n★+200元/人回程行李额升级至25公斤！","Url":"vacation/53656","RecommendPic":"http://media.china-sss.com/pics/gallery/201702/982b7add-2620-4367-8a35-51b626c39b74_201702241355_500_350.jpg","Limit":"9999","xianeCount":"0","olPrice":"1799","Price":"1799","ActivityPrice":null}],"msg":{"Code":"0","Msg":"获取产品列表成功"}};

                if (data.msg && data.msg.Code == '0') {
                    var list = data.detailList, listLen = list.length;
                    if(!_this.conf.maxLen){
                        _this.conf.maxLen = listLen;
                    }
                    var len = (listLen > _this.conf.maxLen ? _this.conf.maxLen : listLen), nowTime = '', btnText = '', btnLink = 'javascript:;';
                    var html = '';
                    if(_this.conf.isServerTime){
                        nowTime = new Date('@DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")');//服务器时间
                    }else{
                        nowTime = new Date();
                    }
                    for (var i = 0; i < len; i++) {
                        if(nowTime.getTime() < new Date(list[i].BeginDate).getTime()){
                            btnText = _this.conf.btnText_notyet;
                        }else if(nowTime.getTime() > new Date(list[i].EndDate).getTime()){
                            btnText = _this.conf.btnText_done;
                        }else{
                            btnText = _this.conf.btnText_act;
                            btnLink = 'http://trip.ch.com/' + list[i].Url + '?utm_medium=CPS&utm_campaign=ChunHang_Pages&utm_source=';
                            if(_this.conf.terminalType == "APP"){
                                btnLink += '&isDisneyTkt=true';
                            }
                        }

                        var data = {
                            RecommendPic: list[i].RecommendPic,
                            RouteName: list[i].RouteName,
                            Price: list[i].Price,
                            btnLink: btnLink,
                            btnText: btnText
                        };
                        html += _this.conf.myTemplate(data);
                    }
                    _this.conf.$wrapDom.html(html).find(_this.conf.itemSelector).removeClass('u-loading');
                    view.prototype.lazyload(_this.conf.$wrapDom);
                    $(window).scroll();
                } else {
                    alert(data.msg.Msg);
                }
            }
        });
    };

    exports.init = init;
});