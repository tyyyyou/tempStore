//lazyload
define('view-lazyload', function(require, exports){
    exports.init = function(el){
        new lazyload(el);
    }
    function lazyload(el){
        var $images = (el ? $(el) : this.$el).find('img[data-src]').each(function(){
            var srcs = $(this).attr('data-src').match(/-(\d+)x(\d+)\.[A-Za-z]+/);
            if(srcs && srcs.length == 3){
                $(this).css({
                    width  : parseInt(srcs[1]),
                    height : parseInt(srcs[2])
                });
            }
        });

        function loadImage() {
            if (!$images.length) return;
            $images = $images.each(function () {
                var $this = $(this), src = $this.attr('data-src');
                if (!src) return;
                if ($this.css('opacity', 0).addClass('u-loading').offset().top < $(document).scrollTop() + $(window).height() && $this.is(":visible")) {
                    $this.removeAttr('data-src');
                    this.onload = function () {
                        $this.animate({opacity: 1}, 500, function () {
                            $this[0].onload = null;
                            $this.removeClass('u-loading');
                        });
                    };
                    $this.attr('src', src);
                }
            }).filter('[data-src]');
        }

        $(window).on({
            resize : loadImage,
            scroll : loadImage
        }).scroll();
    }
});