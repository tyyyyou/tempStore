﻿__inline('../common/fn-gettravelpros.js');
__inline('../common/lazyload.js');

seajs.use(['jquery', 'view-lazyload','fn-getTravelPros', 'plugin5/fn-login'], function ($, lazyload, GetTravelPros, login) {

    function requestLogin(callback){
        if(getCustId().length <= 0){
            globalObj.loginObj.openLogin();
            $('html, body').css('height', '100%');
        }else{
            callback && callback();
        }
    }

    var globalObj = {
        terminalType: "M",
        traPageId: 36591,
        traLineId_one: 40781,
        traLineId_gn: 40777,
        traLineId_cj: 40778,
        traLineId_zb: 40779,
        traBtnText: '抢购',
        loginObj: new login({
            success: function () {
                location.reload();
            }
        }),
        interfaceUrlObj: {
            init: '/airflights/activity119Init',
            toCollect: '/airflights/collectline',
            cancelCollect: '/airflights/removecollectedline',
            getMyCollects: '/airflights/getcollectedlines',
            ipLocate: '/activitiesall/LocateUserCityName'
        },
        collectActivityId: 'Activities689_cn',
        initInterfaceParams: {activityId: 'Activities689_cn'},
        getMyCollectsInterfaceParams: {activityId: 'Activities689_cn'}
    };

    __inline('../public/common.js');

    var pageObj = {
        init: function () {
            this.bindEvt();
        },
        bindEvt: function(){
            $('#J_hotel_nav .J_navitem').click(function(){

            });

            $('#J_btn_bhhrule').click(function(){
                commonObj.openPop($('#J_pop_bhhrule'));
            });
            $('body').on('click', '.bn-back', function(){
                $('html, body').css('height', 'auto');
            });
        },
    };

    pageObj.init();
});