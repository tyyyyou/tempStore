var commonGlobalObj = {};
var commonObj = {
    init: function(){
        lazyload.init($('#p-wrap'));
        this.bindEvt();
    },
    bindEvt: function(){
        var _this = this;

        //活动规则
        $('#J_btnRule').click(function(){

        });

        //机票预订
        $('#p-wrap .J_btnBook').click(function(){
            var $this = $(this);
            commonGlobalObj.oriCode = $this.data('ori');
            commonGlobalObj.desCode = $this.data('des');
            _this.isAct(function(){
                window.open('https://flights.ch.com/' + commonGlobalObj.oriCode + '-' + commonGlobalObj.desCode + '?actId=Activities689_cn&intcmp=chms_activity_' + commonGlobalObj.oriCode + commonGlobalObj.desCode + '_20170926');
            });
        });

        //收藏
        $('#p-wrap .J_collect').click(function(){

        });

        $('#J_nav .J_navitem').click(function(){
            var $this = $(this);
            $this.addClass('active').siblings('.J_navitem').removeClass('active');
            $('#J_tab .J_tabitem').eq($this.index()).show().siblings('.J_tabitem').hide();
        });
    },
    //判断活动状态
    isAct: function(callback){
        switch (globalObj.startState){
            case 0: ; break; //未开始弹框
            case 1: callback && callback(); break; //进行中
            case 2: ; break; //已结束弹框
        }
    }
};
commonObj.init();