var loginObj = new login({
    success: function () {
        location.href = location.href;
    }
});
function requestLogin(callback) {
    var userId = getCustId();
    if (userId.length <= 0) {
        loginObj.openLogin();
    } else {
        callback && callback();
    }
}