﻿__inline('../common//fn-gettravelpros.js');
__inline('../common/lazyload.js');
__inline('commentModule/comment.js');

seajs.use(['jquery', 'view-lazyload','fn-getTravelPros', 'fn-comment', 'plugin5/fn-login', 'ui-citytip', 'ui-overlay'], function ($, lazyload, GetTravelPros, Comment, login) {

    function requestLogin(callback){
        if(getCustId().length <= 0){
            globalObj.loginObj.openLogin();
        }else{
            callback && callback();
        }
    }

    var globalObj = {
        terminalType: "PC",
        traPageId: 36591,
        traLineId_one: 40780,
        traLineId_gn: 40774,
        traLineId_cj: 40775,
        traLineId_zb: 40776,
        traBtnText: '立即抢购',
        loginObj: new login({
            success: function () {
                location.reload();
            }
        }),
        interfaceUrlObj: {
            init: '/airflights/activity119Init',
            toCollect: '/airflights/collectline',
            cancelCollect: '/airflights/removecollectedline',
            getMyCollects: '/airflights/getcollectedlines'
        },
        collectActivityId: 'Activities689_cn',
        initInterfaceParams: {activityId: 'Activities689_cn'},
        getMyCollectsInterfaceParams: {activityId: 'Activities689_cn'}
    };

    __inline('../public/common.js');

    var pageObj = {
        init: function () {
            var _this = this;
            _this.bindEvt();

            //航线查找
            $.CityTip({
                $depart: $('#citySelect'),
                $arrive: $(''),
                afterChoose: function () {
                    var code = this.$active.attr('data-code'),
                        $targetEl = $('#J_locate, #J_locate_more').find('.J_item[data-code=' + code + ']');
                    ($targetEl.length && $targetEl.click()) || commonObj.flightSort({cityCode: code, isHide: true});
                }
            });

            //comment
            Comment.init({
                activityId: "2017090101_hotsale",
                pageSize: 6,
                pageIndex: 1
            }, ".panel-star-edit", {
                itemSelector: ".i-star",
                callback: function(){
                    $(".panel-star-edit").removeClass("warning");
                }
            });
        },
        bindEvt: function(){
            var _this = this;
            $('#citySelect').keyup(function () {
                if ($.trim($(this).val()) == '') {
                    $('#J_locate, #J_locate_more').find('.J_item').removeClass('active');
                    commonObj.flightSort({cityCode: '', isHide: true});
                }
            });
            $('#J_locate, #J_locate_more').on('click', '.J_item', function(){
                var $this = $(this);
                $('#J_locate, #J_locate_more').find('.J_item').removeClass('active');
                $this.addClass('active');
                commonObj.flightSort({cityCode: $(this).data('code'), isHide: true});
            });
            $('#J_locate_morebtn').click(function(){
                var $this = $(this);
                if($this.hasClass('active')){
                    $('#J_locate_more').fadeOut();
                    $this.removeClass('active');
                }else{
                    $('#J_locate_more').fadeIn();
                    $this.addClass('active');
                }
            });
            $('#J_more_close').click(function(){
                $('#J_locate_more').fadeOut();
                $('#J_locate_morebtn').removeClass('active');
            });

            $('#J_snav .J_sidenav_close').click(function(){
                $('#J_snav').fadeOut();
            });
            $('#J_snav .J_navitem').click(function(){
                var targetId = $(this).data('href'), offset = 0, index = 0;
                switch (targetId){
                    case '#ticket-jn': offset = $(targetId).offset().top; index = 0; break;
                    case '#ticket-jw': offset = $(targetId).offset().top; index = 0; break;
                    case '#travel': offset = $('#J_nav').offset().top; index = 1; break;
                    case '#hotel': offset = $('#J_nav').offset().top; index = 2; break;
                }
                $('#J_nav .J_navitem').eq(index).click();
                commonGlobalObj.$window.scrollTop(offset);
            });

            $('#J_btn_bhhrule').click(function(){
                $('#J_bhh_mask, #J_bhh_rule').fadeIn();
                commonGlobalObj.$window.scroll();
            });
            $('#J_btn_bhhkaitong').click(function(){
                $('#J_bhh_mask, #J_bhh_open').fadeIn();
                commonGlobalObj.$window.scroll();
            });
            $('#J_btn_bhhdownload').click(function(){
                $('#J_bhh_mask, #J_bhh_download').fadeIn();
                commonGlobalObj.$window.scroll();
            });
            $('#J_bhh_wrap').click(function(e){
                e.stopPropagation();
            });
            $('#p-wrap').click(function(){
                $('#J_bhh_mask, #J_bhh_rule, #J_bhh_open, #J_bhh_download').fadeOut();
            });
            commonGlobalObj.$window.scroll(function(){
                if($(this).scrollTop() > 300){
                    $('#J_snav').fadeIn();
                }else{
                    $('#J_snav').fadeOut();
                }
            });
        }
    };

    pageObj.init();
});