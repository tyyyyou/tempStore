define("fn-searline", function(require, exports){
    var defaults = {
        $linesPanel: $("#J-lines .J-line-panel"), //航线大分类数组
        linesPanelCls: ".J-line-panel",
        $onelineArr: $("#J-lines .J-line-panel .oneline"), //所有单条航线数组
        $nomachTip: $("#J-linetip"), //没有匹配航线的提示
        $searchInput: $("#J-searIn"),
        $searchClose: $("#J-sear-close"),
        placeSelector: ".J-lineplace",
        $navItem: $("#J-nav .J-navitem"),
        navItemActCls: "active",
    };
    var init = function(conf){
        new SearchLine(conf);
    };
    function SearchLine(conf){
        this.conf = $.extend({}, defaults, conf);
        this.init();
    }
    SearchLine.prototype.init = function(){
        this.bindEvt();
    };
    SearchLine.prototype.unSearlineStatus = function(){
        this.conf.$searchClose.hide();
        this.conf.$onelineArr.show();
        this.conf.$nomachTip.hide();
        this.conf.$searchInput.val("");
        this.conf.$navItem.eq(0).click();
    };
    SearchLine.prototype.bindEvt = function(){
        var _this = this;
        _this.conf.$navItem.click(function(){
            var $this = $(this);
            $this.addClass(_this.conf.navItemActCls).siblings().removeClass(_this.conf.navItemActCls);
            _this.conf.$linesPanel.eq($this.index()).show().siblings(_this.conf.linesPanelCls).hide();
        });

        this.conf.$searchInput.on("input", function () {
            var val = $(this).val();
            if (val) {
                var flag = 0;

                _this.conf.$searchClose.show();

                _this.conf.$navItem.removeClass(_this.conf.navItemActCls);
                _this.conf.$linesPanel.show();
                _this.conf.$onelineArr.each(function () {
                    var $this = $(this);
                    var txt = $this.find(_this.conf.placeSelector).text();
                    if (txt.indexOf(val) > -1) {
                        $this.show();
                    } else {
                        flag++;
                        $this.hide();
                    }
                });
                if (flag == _this.conf.$onelineArr.length) {
                    _this.conf.$nomachTip.show();
                } else {
                    _this.conf.$nomachTip.hide();
                }
            } else {
                _this.unSearlineStatus();
            }
        });

        this.conf.$searchClose.click(function () {
            _this.unSearlineStatus();
        });
    };

    exports.init = init;
});