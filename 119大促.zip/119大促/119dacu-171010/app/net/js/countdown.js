define('countdown', function (require, exports, module) {
    exports.init = function (opts) {
        return new CountDown(opts);
    };
    require('jquery');
    function CountDown(opts) {
        this.defaultOpt = {
            parentId: '#J_ParentContainer',
            dayTen: '#J_DayTen',
            dayBits: '#J_DayBits',
            hourTen: '#J_HourTen',
            hourBits: '#J_HourBits',
            minuteTen: '#J_MinuteTen',
            minuteBits: '#J_MinuteBits',
            secondsTen: '#J_SecondsTen',
            secondsBits: '#J_SecondsBits',
            startDate: new Date(),
            endDate: new Date()
        };
        $.extend(this.defaultOpt, opts);
        this.init();
    }

    CountDown.prototype.init = function () {
        this.dayTen = $(this.defaultOpt.dayTen);
        this.dayBits = $(this.defaultOpt.dayBits);
        this.hourTen = $(this.defaultOpt.hourTen);
        this.hourBits = $(this.defaultOpt.hourBits);
        this.minuteTen = $(this.defaultOpt.minuteTen);
        this.minuteBits = $(this.defaultOpt.minuteBits);
        this.secondsTen = $(this.defaultOpt.secondsTen);
        this.secondsBits = $(this.defaultOpt.secondsBits);
        this.start = this.defaultOpt.startDate.getTime();
        this.end = this.defaultOpt.endDate.getTime();
        this.calculate();
    }
    CountDown.prototype.calculate = function () {
        clearInterval(this.inter);
        var step = 1000,
            localNow = new Date().getTime(),
            now = new Date('@Html.Raw(DateTime.Now.ToString("yyyy\\/MM\\/dd HH:mm:ss"))').getTime(),
            diff = now - localNow;
        var toStart = this.start-now;
        var toEnd = this.end - now;
        var that = this;
        that.callback(toStart, toEnd);
        if(toEnd>0) {
            this.inter = setInterval(function () {
                var nowTime = new Date().getTime();
                toStart = that.start - (diff + nowTime);
                toEnd = that.end - (diff + nowTime);
                if (toStart > 0) {
                    toStart -= step;
                } else if (toEnd > 0) {
                    toEnd -= step;
                }
                that.callback(toStart, toEnd);
                if (toEnd <= 0) {
                    clearInterval(that.inter);
                }
            }, step);
        }
    }

    CountDown.prototype.callback = function (toStart, toEnd) {
        var that = this;
        if (toStart > 0) {
            that.change(toStart);
            this.defaultOpt.callback && this.defaultOpt.callback(1);
        } else if (toEnd < 0) {
            that.change(0);
            this.defaultOpt.callback && this.defaultOpt.callback(0);
        } else {
            that.change(toEnd);
            this.defaultOpt.callback && this.defaultOpt.callback(2);
        }
    }

    CountDown.prototype.change = function (btw) {
        if (btw <= 0) {
            return;
        }
        var day = Math.floor(btw / (1000 * 60 * 60 * 24));
        this.dayTen.text(Math.floor(day / 10));
        this.dayBits.html(day - (Math.floor(day / 10) * 10));

        btw -= day * 1000 * 60 * 60 * 24;
        var hour = Math.floor(btw / (1000 * 60 * 60));
        this.hourTen.text(Math.floor(hour / 10));
        this.hourBits.text(hour - Math.floor(hour / 10) * 10);

        btw -= hour * 1000 * 60 * 60;
        var minute = Math.floor(btw / (1000 * 60));
        this.minuteTen.text(Math.floor(minute / 10));
        this.minuteBits.text(minute - Math.floor(minute / 10) * 10);
        btw -= minute * 1000 * 60;

        var seconds = Math.floor(btw / 1000);
        this.secondsTen.text(Math.floor(seconds / 10));
        this.secondsBits.text(seconds - Math.floor(seconds / 10) * 10);
    }
});