define("fn-comment", function(require,exports){
    var view = require('view'),
        login = require('plugin5/fn-login');
    require('ui-placeholder');
    require('auth');
    require('ui-overlay');
    var loginObj = new login({
        success: function () {
            location.reload();
        }
    });

    var defaults = {
        lang: "zh_cn",
        activityId: "20170214", //需覆盖
        beginTime: "2017-01-01",
        endTime: "2017-12-31",
        pageSize: 6,
        pageIndex: 1,
        $remarkTextEl: $('#remarkTxt')
    };
    var defaults_rating = {
        itemSelector: "",
        callback: function(){}
    };
    var rating = null,
        comment = null; //实例化对象

    var init = function(conf_comment, el_rating, conf_rating){
        comment = new Comment(conf_comment);
        rating = new Rating(el_rating, conf_rating);
    };

    /**
     * 评论星级
     */
    function Rating(el, conf){
        this.$el = $(el);
        this.level = 0;
        this.conf = $.extend({}, defaults_rating, conf);
        this.init();
    }
    Rating.prototype.init = function(){
        this.bindEvt();
    };
    Rating.prototype.bindEvt = function(){
        var self = this;
        self.$el.on("click", self.conf.itemSelector, function(){
            self.level = $(this).index() + 1;
            self.lightOn(self.level);
        }).on("mouseover", self.conf.itemSelector, function(){
            self.lightOn($(this).index() + 1);
        }).on("mouseout", self.conf.itemSelector, function(){
            self.lightOn(self.level);
        });
    };
    Rating.prototype.lightOn = function(num){
        var _this = this, classname = _this.$el.get(0).className, tempCname = '';
        if(classname.indexOf('level') > -1){ //存在level-x的className
            var arr = classname.split(' ');
            for(var i=0;i< arr.length;i++){
                if(arr[i].indexOf('level') > -1){
                    arr[i] = 'level' + num;
                }
            }
            tempCname = arr.join(' ');
        }else{
            tempCname = classname + ' level' + num;
        }
        _this.$el.get(0).className = tempCname;

        (typeof _this.conf.callback === 'function') && _this.conf.callback();
    };

    function Comment(conf){
        this.conf = $.extend({}, defaults, conf);
        this.init();
    }
    Comment.prototype.init = function(){
        this.getComment();
        this.bindEvt();
        this.conf.$remarkTextEl.placeholder();
    };
    /**
     * 获取评论
     */
    Comment.prototype.getComment = function(){
        var self = this;
        var data = {
            "PageSize": self.conf.pageSize,
            "PageIndex": self.conf.pageIndex,
            "Condition": {
                "Lang": self.conf.lang,
                "CustId": "",
                "BeginTime": self.conf.beginTime,
                "EndTime": self.conf.endTime,
                "Type": 1,
                "ActivityId": self.conf.activityId,
                "TerminalType": 'PC'
            }
        };
        $.ajax({
            type: "post",
            url: "/AvtiveComment/QueryRemarkNew",
            data: {"qcParams": JSON.stringify(data)},
            success: function (data) {
                view.prototype.$loader.hide();
                //data = '{"IsSuccess":true,"Msg":null,"Result":{"Total":20,"Data":[{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SDF","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":4,"From":"site","Lang":"zh_cn"},{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SD哈哈F","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":0,"From":"site","Lang":"zh_cn"},{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SDF","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":0,"From":"site","Lang":"zh_cn"},{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SDF","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":0,"From":"site","Lang":"zh_cn"},{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SDF","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":0,"From":"site","Lang":"zh_cn"},{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SDF","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":0,"From":"site","Lang":"zh_cn"},{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SDF","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":0,"From":"site","Lang":"zh_cn"}]},"Code":"0"}';
                //data = JSON.parse(data);
                if (data != "" || data != null || data != undefined) {
                    if (data.IsSuccess && data.Result.Data && data.Result.Data.length) {
                        var htm_title = self.joinTitleHtm(data.Result.Total);
                        $("#viewCom").html(htm_title);
                        var htm = self.joinCommentHtm(data.Result.Data);
                        $("#com-wrap").html(htm);

                        self.pageCount = Math.ceil(data.Result.Total / self.conf.pageSize);
                        var htm = self.createPnum(self.conf.pageIndex, 7, self.pageCount);
                        $("#pnumWrap").html(htm).parents(".page").show();
                        self.changePageCls(self.conf.pageIndex, "unabled");
                    } else {
                        $("#viewCom").hide();
                    }
                } else {
                    alert("系统繁忙,请稍后再试");
                }
            },
            error: function () {
            }
        });
    };
    Comment.prototype.bindEvt = function(){
        var self = this;
        //提交评论
        $("#J_btn_submit").click(function () {
            var level = rating.level;
            if(!($('#loginState').val() == 'Y'? true: false)){
                loginObj.openLogin()
                return;
            }

            var remarkTxt = $("#remarkTxt").val();
            if (remarkTxt == "" || remarkTxt == null || remarkTxt == undefined) {
                alert("您暂未输入点评内容，请重新输入");
                $("#remarkTxt").addClass("warning");
                return;
            }
            if (remarkTxt.length > 200) {
                alert("您的字数超过200啦，请删减一下哦~");
                $("#remarkTxt").addClass("warning");
                return;
            }
            if (!level) {
                alert("您暂未评定星级，请重新输入！");
                $(".panel-star-edit").addClass("warning");
                return;
            }

            $.ajax({
                type: "post",
                url: "/AvtiveComment/CheckActivityCanComment",
                data: {
                    "ActivityId": self.conf.activityId
                },
                beforeSend: function(){
                    view.prototype.$loader.show();
                },
                success: function (data) {
                    //data = '{"IsSuccess":true,"Msg":null,"IsCanComment":true,"Result":{"Total":1,"Data":[{"RemarkID":"830af43c-a37c-4226-8c00-f4f69cb3b314","IsDefault":0,"FlightData":"0001-01-01 00:00:00","FlightNo":"","Status":0,"CreatedBy":"system","ModifiedBy":"system","Created":"2017-02-03 17:12:29","SupportNum":0,"UserId":146508468,"CustId":"9C0107157161","UserName":"SDF","ActivityId":"20170214","Type":1,"Sex":0,"Remark":"asdasdasd","Level":0,"From":"site","Lang":"zh_cn"}]},"Code":"0"}';
                    //data = JSON.parse(data);
                    if (data != "" || data != null || data != undefined) {
                        if (data.Code == "0" && data.IsCanComment) { //可以评论
                            $.ajax({
                                type: "post",
                                url: "/AvtiveComment/AddRemarkList",
                                data: {
                                    "ActivityId": self.conf.activityId,
                                    "Remark": remarkTxt,
                                    "Level": level,
                                    "Lang": self.conf.lang
                                },
                                success: function (data) {
                                    view.prototype.$loader.hide();
                                    if (data != "" || data != null || data != undefined) {
                                        if (data.Code == "0") {
                                            alert("感谢您的参与！\n稍后将显示您的评论");
                                        } else {
                                            alert("您太积极啦~明天再来参与点评吧");
                                        }
                                    } else {
                                        alert("系统繁忙,请稍后再试");
                                    }
                                },
                                error: function () {
                                }
                            });
                        } else {
                            view.prototype.$loader.hide();
                            alert("sorry，该活动暂不能评论！");
                        }
                    } else {
                        alert("系统繁忙,请稍后再试");
                    }
                },
                error: function () {
                }
            });
        });
        //点赞事件
        $("#viewCom").on("click", ".J-clickzan", function () {
            if(!($('#loginState').val() == 'Y'? true: false)){
                loginObj.openLogin()
                return;
            }

            var $this = $(this);
            var remarkId = $this.parent().attr('data-remarkId');
            $.ajax({
                type: "post",
                url: "/AvtiveComment/CheckRemarkCanSupport",
                data: {
                    "remarkId": remarkId
                },
                beforeSend: function(){
                    view.prototype.$loader.show();
                },
                success: function (data) {
                    //data = '{"Code": "0", "IsCanSupport":true}';
                    //data = JSON.parse(data);
                    if (data != "" || data != null || data != undefined) {
                        if (data.Code == "0") {
                            if (data.IsCanSupport) { //可以点赞
                                $.ajax({
                                    type: "post",
                                    url: "/AvtiveComment/AddActivitySupportAndUpdateSupportNum",
                                    data: {
                                        "remarkId": remarkId
                                    },
                                    success: function (data) {
                                        //data = '{"Code": "0", "IsCanSupport":true}';
                                        //data = JSON.parse(data);
                                        view.prototype.$loader.hide();
                                        if (data != "" || data != null || data != undefined) {
                                            if (data.Code == "0") {//点赞成功
                                                $this.parent().find('.count-zan').html(parseInt($this.next('.count-zan').html()) + 1);
                                                $this.replaceWith('<i class="J-clickzan i-zan iconfont bg_base_xin active">&#xe63c;</i>');
                                            }
                                        } else {
                                            alert("系统繁忙,请稍后再试");
                                        }
                                    },
                                    error: function () {
                                    }
                                });
                            } else {
                                view.prototype.$loader.hide();
                                alert("您已对该评论点过赞了");
                            }
                        }
                    } else {
                        alert("系统繁忙,请稍后再试");
                    }
                }
            });
        });
        //分页
        $("#page").on("click", ".page_num", function () {
            var that = this;
            var $target = $(this);
            if (!$target.hasClass("active")) {
                $("#com-wrap").empty();
                self.conf.pageIndex = parseInt($target.text());
                view.prototype.$loader.show();
                self.getComment();
            }
        });
        $("#page").on("click", ".page_btn", function () {
            var $target = $(this);
            if (!$target.hasClass("unabled")) {
                var $pnum = $("#pnumWrap .page_num"), $targetPnum;
                for (var i = 0; i < $pnum.length; i++) {
                    var $curPnum = $($pnum[i]);
                    if ($curPnum.hasClass("active")) {
                        if ($target.is("#prePage")) {	//点击上一页
                            $targetPnum = $curPnum.prev();
                            self.conf.pageIndex--;
                        } else { //点击下一页
                            $targetPnum = $curPnum.next();
                            self.conf.pageIndex++;
                        }
                        break;
                    }
                }

                $("#com-wrap").empty();
                view.prototype.$loader.show();
                self.getComment();
            }
        });

        $("#remarkTxt").on("focus", function () {
            $(this).removeClass("warning");
        });
        $("#remarkTxt").on("propertychange", function () {
            var $this = $(this), val = $this.val(), len = val.length;
            if(len > 200){
                $this.val(val.substr(0, 200));
            }
            $('#J_word_count').text($this.val().length);
        });
    };
    Comment.prototype.joinTitleHtm = function(total){
        return '<p class="com-l1">全部评论(' + total + ')</p><div id="com-wrap"></div>';
    };

    /**
     * 拼接所有用户评论，返回html string
     */
    Comment.prototype.joinCommentHtm = function(arr){
        var htm = [];
        for (var temp = 0; temp < arr.length; temp++) {
            var ctime = new Date(arr[temp].Created.toString().replace(/-/g, "/"));
            var ctimeStr = (ctime.getMonth() + 1) + "月" + ctime.getDate() + "日 " + ctime.getHours() + ":" + ctime.getMinutes();
            htm.push('<div class="item-com f-cb">');
            htm.push('<div class="fl fl-1">');
            htm.push('<img src="//media.springairlines.com/SpringAirlines/images/Activitiesall/Activities538/v170214/pic.png" alt="用户头像" />');
            htm.push('</div>');
            htm.push('<div class="fl fl-2">');
            htm.push('<div class="com-l2-l1 f-cb">');
            htm.push('<span class="cm-uname fl">' + arr[temp].UserName + '</span>');
            htm.push('<span id="createTime" class="comments-time fr">' + ctimeStr + '</span>');
            htm.push('</div>');
            htm.push('<div class="panel-star panel-star-show f-cb level'+arr[temp].Level+'"><span class="i-star fl"></span><span class="i-star fl"></span><span class="i-star fl"></span><span class="i-star fl"></span><span class="i-star fl"></span></div>');
            htm.push('<p class="com-l3" id="comCont">' + arr[temp].Remark + '</p>');
            htm.push('</div>');
            htm.push('<div class="panel-zan" data-remarkId="' + arr[temp].RemarkID + '">');
            if(arr[temp].OwnSupport){
                htm.push('<i class="J-clickzan i-zan iconfont bg_base_xin active">&#xe63c;</i>');
            }else{
                htm.push('<i class="J-clickzan i-zan iconfont hotel-4">&#xe681;</i>');
            }
            htm.push('<em class="count-zan">' + arr[temp].SupportNum + '</em></div></div>');
        }
        return htm.join('');
    };

    /**
     * 添加页码
     */
    Comment.prototype.createPnum = function(curPnum, step, allPnum) {
        var pageArr = [], halfStep = Math.floor(step / 2);
        if (allPnum > step) {
            if (curPnum <= halfStep) {
                for (var i = 0; i < step; i++) {
                    pageArr.push(i + 1);
                }
            } else if (curPnum >= (allPnum - halfStep)) {
                for (var i = (allPnum - step); i < allPnum; i++) {
                    pageArr.push(i + 1);
                }
            } else {
                for (var i = (curPnum - halfStep - 1); i < (curPnum + halfStep); i++) {
                    pageArr.push(i + 1);
                }
            }
        } else {
            for (var i = 0; i < allPnum; i++) {
                pageArr.push(i + 1);
            }
        }

        var htm = '';
        for (var i = 0; i < pageArr.length; i++) {
            if (curPnum == pageArr[i]) {
                htm += '<span class="page_num active">' + pageArr[i] + '</span>';
            } else {
                htm += '<span class="page_num">' + pageArr[i] + '</span>';
            }
        }
        return htm;
    };

    Comment.prototype.changePageCls = function(txt, clsname) {
        if ((txt == "1") && (txt == this.pageCount)) {
            $("#prePage").addClass(clsname);
            $("#nextPage").addClass(clsname);
            return;
        }
        if (txt == "1") { //若结果页为第一页
            $("#prePage").addClass(clsname);
            $("#nextPage").removeClass(clsname);
        } else if (txt == this.pageCount) { //若结果页为最后一页
            $("#prePage").removeClass(clsname);
            $("#nextPage").addClass(clsname);
        } else {
            $("#prePage").removeClass(clsname);
            $("#nextPage").removeClass(clsname);
        }
    };

    exports.init = init;
});