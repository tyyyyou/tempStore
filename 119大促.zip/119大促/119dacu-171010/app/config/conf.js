var apiUrl = 'https://pages.ch.com', wxApiUrl = 'http://wx.ch.com/';
var pathUrl = "//10.131.10.29:8094";
var apiConfig = {
    activityId: '20170503_89dc',
    searchLineByID: {
        url: '//trippages.ch.com/activity/ActivityPage/SearchLineByID',
        type: 'POST'
    },
    init: {
        url: pathUrl + '/ECommercePlatform/m/bigpromotion/init',
        type: 'POST',
    },
    queryRemark: {
        url: apiUrl + '/AvtiveComment/QueryRemarkNew',
        type: 'post'
    },
    addRemarkList: {
        url: apiUrl + '/AvtiveComment/AddRemarkList',
        type: 'post'
    },
    support: {
        url: apiUrl + '/AvtiveComment/AddActivitySupportAndUpdateSupportNum',
        type: 'post'
    },
    checkLogin: {
        url: wxApiUrl + 'userLogin/checkLogin',
        type: 'POST'
    },
    wxUrl: {
        url: wxApiUrl + 'userLogin/loginValidateNew'
    }
};

