__inline('../common/flipclock.js');
__inline('../common/fn-gettravelpros.js');

var commonGlobalObj = {
    timerObj: {
        startTime: new Date('2017/11/9 10:00:00'),
        currentTime: (window.currentTime || new Date()),
        endTime: new Date('2017/11/11 22:00:00')
    },
    $window: $(window),
    $loader: view.prototype.$loader,
    btwTime: 0,
    isSpringPass: false
};
var commonObj = {
    init: function(){
        var _this = this;

        lazyload.init($('#p-wrap'));
        _this.bindEvt();
        _this.initBaseData();
        _this.locateFlightCity();
        if(globalObj.terminalType.toUpperCase() != 'WEBCHAT'){
            //_this.initInterface(globalObj.initInterfaceParams);//暂时
        }else{
            _this.getMyCollectsInterface(globalObj.getMyCollectsInterfaceParams, true);
        }

        //1元旅游产品
        GetTravelPros.init({
            pageId: globalObj.traPageId,
            lineId: globalObj.traLineId_one,
            $wrapDom: $('#J_tra_one'),
            isServerTime: true,
            terminalType: globalObj.terminalType,
            maxLen: 4,
            itemSelector: '.J_traitem',
            btnText_act: globalObj.traBtnText || '',
            myTemplate: function(data){
                var html = '';
                if(globalObj.terminalType.toUpperCase() === 'PC'){
                    html = _this.joinTraHtmlPC(data, 'c170925ssy');
                }else{
                    html = _this.joinTraHtmlM(data, 'c170925ssy');
                }
                return html;
            }
        });
    },
    bindEvt: function(){
        var _this = this;

        $('#J_activelvyi').click(function(){
            var $this = $(this);
            requestLogin(function(){
                window.open($this.data('href'));
            });
        });

        //活动规则
        $('#J_btnRule').click(function(){
            _this.openPop($('#J_pop_rule'));
        });

        //机票预订
        $('#p-wrap, #J_pop_collect').on('click', '.J_btnBook', function(){
            var $this = $(this);
            commonGlobalObj.oriCode = $this.data('ori');
            commonGlobalObj.desCode = $this.data('des');
            _this.isAct(function(){
                var link = '';
                if(globalObj.terminalType.toUpperCase() === 'PC'){
                    link = 'https://flights.ch.com/' + commonGlobalObj.oriCode + '-' + commonGlobalObj.desCode + '?actId=Activities689_cn&intcmp=chms_activity_' + commonGlobalObj.oriCode + commonGlobalObj.desCode + '_20170926';
                }else if(globalObj.terminalType.toUpperCase() === 'M'){
                    link = 'https://flights.ch.com/' + commonGlobalObj.oriCode + '-' + commonGlobalObj.desCode + '?actId=Activities689_cn';
                }
                window.open(link);
            });
        });
        $('#J_tqgo').click(function(){
            var link2 = '';
            if(globalObj.terminalType.toUpperCase() === 'PC'){
                link2 = 'https://flights.ch.com/' + commonGlobalObj.oriCode + '-' + commonGlobalObj.desCode + '.html?delay=15&actId=Activities689_cn&intcmp=chms_activity_' + commonGlobalObj.oriCode + commonGlobalObj.desCode + '_20170926';
            }else if(globalObj.terminalType.toUpperCase() === 'M'){
                link2 = 'https://flights.ch.com/' + commonGlobalObj.oriCode + '-' + commonGlobalObj.desCode + '.html?delay=15&actId=Activities689_cn';
            }
            window.open(link2);
        });

        //我的收藏pc
        $('#J_tocollect').click(function(){
            requestLogin(function(){
                _this.getMyCollectsInterface(globalObj.getMyCollectsInterfaceParams, false);
            });
        });
        //添加/取消收藏
        $('#p-wrap, #J_pop_collect').on('click', '.J_collect', function(){
            var $this = $(this),
                $bookBtn = $this.closest('.oneline').find('.J_btnBook'),
                curOriCode = $bookBtn.data('ori'),
                curDesCode = $bookBtn.data('des');
            requestLogin(function(){
                if($this.hasClass('unable')){
                    alert('页面初始化中，请稍候再试！');
                    return;
                }
                if($this.hasClass('done')){ //取消收藏
                    $.ajax({
                        url: globalObj.interfaceUrlObj.cancelCollect,
                        type: 'post',
                        data: {
                            activityId: globalObj.collectActivityId,
                            collectId: $this.data('id')
                        },
                        beforeSend: function(){
                            commonGlobalObj.$loader.show();
                        },
                        success: function(data){
                            commonGlobalObj.$loader.hide();
                            (typeof data === 'string') && (data = JSON.parse(data));
                            if((typeof data === 'undefined') || data === ''){
                                alert('接口暂无数据，请稍后再试');
                            }
                            if(data.isBizSuccess && data.isSuccess){
                                var $parent = $this.closest('.J_pop');
                                if($parent.length){
                                    $this.closest('.oneline').remove();
                                    if(!$parent.find('.oneline').length){
                                        $parent.find('.J_cont').html('<br />暂无收藏<br /><br />');
                                    }
                                }

                                //同步相关航线
                                $('#p-wrap .J_pageline_wrap').each(function(){
                                    $(this).find('.oneline').each(function(){
                                        var $bookBtn = $(this).find('.J_btnBook');
                                        if((curOriCode == $bookBtn.data('ori') && (curDesCode == $bookBtn.data('des')))){
                                            $(this).find('.J_collect').removeClass('done').find('.J_collect_text').text('收藏');
                                        }
                                    });
                                });
                            }else{
                                alert('系统繁忙，请稍后再试！');
                            }
                        },
                        error: function(){
                            commonGlobalObj.$loader.hide();
                            alert('系统错误，请稍后再试！');
                        }
                    });
                }else{ //添加收藏
                    $.ajax({
                        url: globalObj.interfaceUrlObj.toCollect,
                        type: 'post',
                        data: {
                            activityId: globalObj.collectActivityId,
                            oriCode: $bookBtn.data('ori'),
                            oriCity: $bookBtn.data('.J_place_ori'),
                            destCode: $bookBtn.data('des'),
                            destCity: $bookBtn.data('.J_place_des')
                        },
                        beforeSend: function(){
                            commonGlobalObj.$loader.show();
                        },
                        success: function(data){
                            commonGlobalObj.$loader.hide();
                            (typeof data === 'string') && (data = JSON.parse(data));
                            if((typeof data === 'undefined') || data === ''){
                                alert('接口暂无数据，请稍后再试');
                            }
                            if(data.isBizSuccess && data.isSuccess){
                                //同步相关航线
                                $('#p-wrap .J_pageline_wrap').each(function(){
                                    $(this).find('.oneline').each(function(){
                                        var $bookBtn = $(this).find('.J_btnBook');
                                        if((curOriCode == $bookBtn.data('ori') && (curDesCode == $bookBtn.data('des')))){
                                            $(this).find('.J_collect').addClass('done').attr('data-id', data.data).find('.J_collect_text').text('已收藏');
                                        }
                                    });
                                });

                                _this.openPop($('#J_pop_success'));
                            }else{
                                alert('系统繁忙，请稍后再试！');
                            }
                        },
                        error: function(){
                            commonGlobalObj.$loader.hide();
                            alert('系统错误，请稍后再试！');
                        }
                    });
                }
            });
        });

        $('#J_nav .J_navitem').click(function(){
            var $this = $(this), index = $this.index();
            $this.addClass('active').siblings('.J_navitem').removeClass('active');
            if(index !== 4){
                $('#J_tab>.J_tabitem').eq(index).show().siblings('.J_tabitem').hide();
            }
            if(index === 0 || index === 1){
                $('#J_search_wrap').show();
            }else{
                $('#J_search_wrap').hide();
            }
            if((globalObj.terminalType.toUpperCase === 'PC') && (index === 1)
                || (globalObj.terminalType.toUpperCase !== 'PC') && (index === 2)){
                //正常旅游产品-国内
                GetTravelPros.init({
                    pageId: globalObj.traPageId,
                    lineId: globalObj.traLineId_gn,
                    $wrapDom: $('#J_tra_normal_gn'),
                    isServerTime: true,
                    terminalType: globalObj.terminalType,
                    maxLen: 16,
                    itemSelector: '.J_traitem',
                    btnText_act: globalObj.traBtnText || '',
                    myTemplate: function(data){
                        var html = '';
                        if(globalObj.terminalType.toUpperCase() === 'PC'){
                            html = _this.joinTraHtmlPC(data, 'c170925ssy');
                        }else{
                            html = _this.joinTraHtmlM(data, 'c170925ssy');
                        }
                        return html;
                    }
                });
                //正常旅游产品-出境
                GetTravelPros.init({
                    pageId: globalObj.traPageId,
                    lineId: globalObj.traLineId_cj,
                    $wrapDom: $('#J_tra_normal_cj'),
                    isServerTime: true,
                    terminalType: globalObj.terminalType,
                    maxLen: 16,
                    itemSelector: '.J_traitem',
                    btnText_act: globalObj.traBtnText || '',
                    myTemplate: function(data){
                        var html = '';
                        if(globalObj.terminalType.toUpperCase() === 'PC'){
                            html = _this.joinTraHtmlPC(data, 'c170925ssy');
                        }else{
                            html = _this.joinTraHtmlM(data, 'c170925ssy');
                        }
                        return html;
                    }
                });
                //正常旅游产品-周边
                GetTravelPros.init({
                    pageId: globalObj.traPageId,
                    lineId: globalObj.traLineId_zb,
                    $wrapDom: $('#J_tra_normal_zb'),
                    isServerTime: true,
                    terminalType: globalObj.terminalType,
                    maxLen: 16,
                    itemSelector: '.J_traitem',
                    btnText_act: globalObj.traBtnText || '',
                    myTemplate: function(data){
                        var html = '';
                        if(globalObj.terminalType.toUpperCase() === 'PC'){
                            html = _this.joinTraHtmlPC(data, 'c170925ssy');
                        }else{
                            html = _this.joinTraHtmlM(data, 'c170925ssy');
                        }
                        return html;
                    }
                });
            }
            commonGlobalObj.$window.scroll();
        });

        $('#J_hotel_nav .J_hnavitem').click(function(){
            $('#J_hotel_tab>.J_tabitem').eq($(this).index()).show().siblings('.J_tabitem').hide();
        });

        $('#J_lineSearch').on('input', function(){
            var $this = $(this), val = $this.val();
            if(val){
                $this.addClass('nobg');
                $('#J_lineSearch_close').show();
            }else{
                $this.removeClass('nobg');
                $('#J_lineSearch_close').hide();
            }

            commonObj.flightSort({cityName: val, isHide: true, isSwitchTab: true});
        });
        $('#J_lineSearch_close').click(function(){
            $('#J_lineSearch_close').hide();
            $('#J_lineSearch').val('').removeClass('nobg');
            commonObj.flightSort({cityName: '', isHide: true});
        });

        $('.J_pop .J_pop_close').click(function(){
            $(this).closest('.J_pop').hide();
            $('#J_mask').hide();
        });
        $('.J_pop').click(function(e){
            e.stopPropagation();
        });
        $('#J_mask').click(function(){
            $('.J_pop .J_pop_close').click();
        });
    },
    //初始化倒计时
    initBaseData: function() {
        var c = commonGlobalObj.timerObj.currentTime.getTime(),
            s = commonGlobalObj.timerObj.startTime.getTime(),
            e = commonGlobalObj.timerObj.endTime.getTime();
        commonGlobalObj.timeArr = [{
            title: '距活动开始还剩下',
            state: 0,
            btw: (s - c)
        }, {
            title: '距离活动结束还剩下',
            state: 1,
            btw: (e - (c > s ? c : s))
        }];
        this.startClock()
    },
    //开始倒计时
    startClock: function() {
        var _this = this;
        if (commonGlobalObj.timeArr.length > 0) {
            var item = commonGlobalObj.timeArr.shift();
            commonGlobalObj.startState = item.state;
            var seconds = parseInt(item.btw / 1000); //秒必须为整数,否则有bug
            if (seconds > 0) {
                $('#J_TimerTxt').text(item.title);
                var clocker = $('#J_Timer').FlipClock({
                    autoStart: false,
                    clockFace: 'DailyCounter',
                    language: 'chinese',
                    callbacks: {
                        interval: function () {
                            commonGlobalObj.btwTime = clocker.time.time;
                            if(commonGlobalObj.isSpringPass && ((commonGlobalObj.btwTime < 1800 && commonGlobalObj.btwTime > 0))){
                                $('#p-wrap .J_btnBook').removeClass('unable');
                            }
                        },
                        stop: function () {
                            _this.startClock();
                        },
                        start: function(){
                            if(commonGlobalObj.startState == 1){
                                $('#p-wrap .J_btnBook').removeClass('unable');
                            }
                        }
                    }
                });
                clocker.setTime(seconds);
                clocker.setCountdown(true);
                clocker.start();
            } else {
                _this.startClock();
            }
        } else {
            $('#J_Timer').FlipClock({autoStart: false, clockFace: 'DailyCounter', language: 'chinese'});
            commonGlobalObj.startState = 2;
            $('#J_TimerTxt').text('活动已经结束');
        }
    },
    //判断活动状态
    isAct: function(callback){
        var _this = this;
        if(commonGlobalObj.startState === 0){ //未开始
            if (commonGlobalObj.btwTime < 1800 && commonGlobalObj.btwTime > 0) {
                requestLogin(function(){
                    if(commonGlobalObj.isSpringPass){//是绿翼会员，则购票
                        callback && callback();
                    }else{//不是绿翼会员，则弹框
                        _this.openPop($('#J_pop_notyet'));
                    }
                });
            }else{
                _this.openPop($('#J_pop_notyet'));
            }
        }else if(commonGlobalObj.startState === 2){ //已结束
            _this.openPop($('#J_pop_over'));
        }else{
            callback && callback();
        }
    },
    //移动端旅游产品拼接
    joinTraHtmlM: function(data, trackCode){
        var html = [];
        html.push('<a class="tra-panel u-loading J_traitem" href="' + data.btnLink + trackCode + '" target="_blank">');
        html.push('<img class="tra-img db w100" data-src="' + data.RecommendPic + '" alt=""/>');
        html.push('<span class="tra-info" title="' + data.RouteName + '">' + data.RouteName + '</span>');
        html.push('<span class="tra-row">');
        html.push('<span class="tra-price"><em class="num">' + data.Price + '</em>元起</span>');
        html.push('<span class="ui-btn btn-normal tra-btn">' + data.btnText + '</span>');
        html.push('</span>');
        html.push('</a>');
        return html.join('');
    },
    //pc端旅游产品拼接
    joinTraHtmlPC: function(data, trackCode){
        var html = [];
        html.push('<a class="tra-panel fl u-loading J_traitem" href="' + data.btnLink + trackCode + '" target="_blank">');
        html.push('<div class="tra-img-wrap"><img class="tra-img" data-src="' + data.RecommendPic + '" alt=""/></div>');
        html.push('<span class="tra-info" title="' + data.RouteName + '">' + data.RouteName + '</span>');
        html.push('<span class="tra-row f-cb">');
        html.push('<span class="tra-price fl">&yen;<em class="num">' + data.Price + '</em><em class="qi">起</em></span>');
        html.push('<span class="ui-btn btn-normal tra-btn">' + data.btnText + '</span>');
        html.push('</span>');
        html.push('</a>');
        return html.join('');
    },
    //城市定位
    locateFlightCity: function () {
        var _this = this;
        $.ajax({
            type: 'post',
            url: globalObj.interfaceUrlObj.ipLocate,
            success: function (data) {
                data.CityCode && commonObj.flightSort({cityCode: data.CityCode,isHide: false});
            }
        });
    },
    //航线排序
    flightSort: function(param){
        var cityCode = param.cityCode,
            cityName = param.cityName,
            isHide = param.isHide,
            isSwitchTab = param.isSwitchTab;
        if(cityCode == '' || cityName == ''){
            $('#J_tab .oneline').show();
            $('#J_tab .J_line_tip').hide();
            return;
        }

        $('#J_tab .J_linetab_item').each(function(){
            var flag = 0,
                $parent = $(this),
                $linesArr = $parent.find('.oneline'),
                $tip = $parent.find('.J_line_tip');
            $linesArr.each(function(){
                var $this = $(this);
                if(cityCode == $this.find('.J_btnBook').data('ori')
                    || cityCode == $this.find('.J_btnBook').data('des')
                    || ($this.find('.J_place_ori').text().indexOf(cityName) > -1)
                    || ($this.find('.J_place_des').text().indexOf(cityName) > -1)){
                    if(isHide){
                        flag++;
                        $this.show()
                    }
                }else{
                    if(isHide){
                        $this.hide();
                    }else{
                        $parent.append($this);
                    }
                }
            });
            if(isHide){
                if(flag){
                    $tip.hide();
                    $parent.attr('data-ismatch', '1');
                }else{
                    $tip.show();
                    $parent.attr('data-ismatch', '0');
                }
            }
        });

        if(isHide && isSwitchTab){
            var index = $('#J_nav .J_navitem.active').index(), anotherIndex;
            if(index == 0){
                anotherIndex = 1;
            }else if(index == 1){
                anotherIndex = 0;
            }
            if(($('#J_tab .J_linetab_item').eq(index).attr('data-ismatch') == '0') && ($('#J_tab .J_linetab_item').eq(anotherIndex).attr('data-ismatch') == '1')){
                $('#J_nav .J_navitem').eq(anotherIndex).click();
            }
        }
    },
    openPop: function($el){
        if(globalObj.terminalType.toUpperCase() === 'PC'){
            $el.overlay().open();
        }else{
            $('#J_mask').show();
            $el.show();
        }
    },
    joinCollectLineHtml: function(data){
        var html = [], str = '', tempClass = '';
        if(data.isMatched){
            if(globalObj.terminalType.toUpperCase() == 'PC'){
                if(data.isTax){
                    str = '<i class="i-tax">含税价</i>';
                }
                html.push('<div class="oneline fl f-cb">');
                html.push('<a class="ui-pop-close collect-cancel iconfont bg_icon_Close J_collect done" data-id="' + data.collectId + '" href="javascript:;">&#xe652;</a>');
                html.push('<i class="ol-deco ui-bg left fl"></i>');
                html.push('<div class="ol-panel fl">');
                html.push('<p class="ol-place">' + data.curOriName + '<i class="ui-sprite i-plane"></i>' + data.curDesName + '</p>');
                html.push('<p class="ol-row f-cb">');
                html.push('<span class="fl ol-price">&yen;<em class="num">' + data.curPrice + '</em><em class="qi">起</em>');
                html.push(str);
                html.push('</span>');
                html.push('<a class="fr ui-btn btn-normal btn-book J_btnBook" href="javascript:;" data-ori="' + data.oriCode + '" data-des="' + data.destCode + '">立即抢购</a>');
                html.push('</p>');
                html.push('</div>');
                html.push('<i class="ol-deco ui-bg right fr"></i>');
                html.push('</div>');
            }else{
                if(data.isTax){
                    tempClass = ' notax';
                }
                html.push('<p class="c-oneline oneline' + tempClass + '">');
                html.push('<a class="ui-close ui-pop-close ui-cline-close iconfont bg_icon_Close J_pop_close J_collect done" data-id="' + data.collectId + '" href="javascript:;">&#xe652;</a>');
                html.push('<span class="cline-place">');
                html.push('<span class="J_cline_ori">' + data.curOriName + '</span>');
                html.push('<i class="ui-icon i-plane"></i>');
                html.push('<span class="J_cline_des">' + data.curDesName + '</span>');
                html.push('</span>');
                html.push('<span class="cline-right">');
                html.push('<span class="cl-price"><em class="num">' + data.curPrice + '</em>元起</span>');
                html.push('<a class="ui-btn btn-book2 J_btnBook" href="javascript:;" data-ori="' + data.oriCode + '" data-des="' + data.destCode + '">抢购</a>');
                html.push('</span>');
                html.push('</p>');
            }
        }
        return html.join('');
    },
    //调用我的收藏接口
    getMyCollectsInterface: function(params, isInit){
        var _this = this;
        $.ajax({
            url: globalObj.interfaceUrlObj.getMyCollects,
            type: 'post',
            data: params,
            beforeSend: function(){
                if(!isInit){
                    commonGlobalObj.$loader.show();
                }
            },
            success: function(data){
                commonGlobalObj.$loader.hide();
                (typeof data === 'string') && (data = JSON.parse(data));
                if((typeof data === 'undefined') || data === ''){
                    alert('接口暂无数据，请稍后再试');
                }
                if(data.isBizSuccess && data.isSuccess){
                    //我的收藏列表
                    var str = [], arr = data.data;
                    if(arr.length){
                        commonGlobalObj.collectLineArr = arr;
                        var collectArr = commonGlobalObj.collectLineArr, len = collectArr.length;

                        //获取页面上航线相关信息 并保存下来
                        for(var i=0;i<len;i++){
                            $('#p-wrap .J_pageline_wrap').each(function(){
                                $(this).find('.oneline').each(function(){
                                    var $oneline = $(this), $bookBtn = $(this).find('.J_btnBook');
                                    if((collectArr[i].oriCode == $bookBtn.data('ori') && (collectArr[i].destCode == $bookBtn.data('des')))){
                                        var tempPrice = parseInt($oneline.find('.J_line_price').text());
                                        collectArr[i].curPrice = collectArr[i].curPrice || tempPrice;
                                        collectArr[i].isMatched = true;
                                        if(collectArr[i].curPrice >= tempPrice){
                                            collectArr[i].curOriName = $oneline.find('.J_place_ori').text();
                                            collectArr[i].curDesName = $oneline.find('.J_place_des').text();
                                            collectArr[i].isTax = !($oneline.hasClass('notax'));
                                        }
                                    }
                                });
                            });
                        }

                        var tempArr = commonGlobalObj.collectLineArr;
                        for(var j=0;j<tempArr.length;j++){
                            str.push(_this.joinCollectLineHtml(tempArr[j]));
                        }

                    }else{
                        str.push('<br />暂无收藏<br /><br />');
                    }

                    $('#J_pop_collect').find('.J_cont').html(str.join(''));
                    if(!isInit){
                        _this.openPop($('#J_pop_collect'));
                    }
                }else{
                    alert('系统繁忙，请稍后再试！');
                }
            },
            error: function(){
                commonGlobalObj.$loader.hide();
                alert('系统错误，请稍后再试！');
            }
        });
    },
    initInterface: function(params){
        $.ajax({
            url: globalObj.interfaceUrlObj.init,
            type: 'post',
            data: params,
            success: function(data){
                if(data.ifSuccess || data.IsSuccess){
                    var tempArr = [];

                    commonGlobalObj.currentTime = data.Result.CurrentTime ? data.Result.CurrentTime : data.currentTime;
                    commonGlobalObj.startTime = data.Result.StartTime ? data.Result.StartTime : data.startTime;
                    commonGlobalObj.endTime = data.Result.EndTime ? data.Result.EndTime : data.endTime;

                    if(globalObj.terminalType == 'APP'){
                        commonGlobalObj.isSpringPass = (data.identifiMember == 'Y') ?  true: false;
                    }else{
                        tempArr = data.Result.CollectLines;
                        commonGlobalObj.isSpringPass = (data.Result.UserStatus == 2) ?  true: false;
                    }
                    if(commonGlobalObj.isSpringPass){
                        $('#J_activelvyi').hide();
                    }

                    if(tempArr.length){
                        for(var i=0;i<tempArr.length;i++){
                            $('#p-wrap .J_pageline_wrap').each(function(){
                                $(this).find('.oneline').each(function(){
                                    var $oneline = $(this), $bookBtn = $(this).find('.J_btnBook');
                                    if((tempArr[i].OriCode == $bookBtn.data('ori') && (tempArr[i].DestCode == $bookBtn.data('des')))){
                                        //已收藏的所有航线
                                        $oneline.find('.J_collect').addClass('done').attr('data-id', tempArr[i].CollectId).find('.J_collect_text').text('已收藏');
                                    }
                                });
                            });
                        }
                    }
                    $('#p-wrap .J_pageline_wrap .J_collect').removeClass('unable');
                }else{
                    alert('初始化接口错误，请稍候再试！');
                }
            },
            error: function(){
                alert('初始化接口错误，请稍候再试！');
            }
        });
    }
};
commonObj.init();