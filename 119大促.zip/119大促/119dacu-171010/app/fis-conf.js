fis
    .set('live', '../live')
    .set('pc', '../net')
    .set('mobile', '../mobile')
    .set('wechat', '../wechat')
    .set('net', '//media.springairlines.com/cache/springairlines/images/activitiesall/activities664')
    .set('app', '../')
    //.set('app', '//media.springairlines.com/cmsstatic/2017/150676/img')
    //.set('local', '//10.131.8.75:88')
    .set('local', '//192.168.0.101:88')
    .set('cshtml', 'D:\\sourceCode\\websitee\\branches\\pages\\UI\\SpringAirlines\\Views\\Activitiesall')
    /*.hook('commonjs', {
        extList: ['.js', '.jsx', '.es', '.ts', '.tsx'],
        paths: {
            $: '/node_modules/fis-mod/mod.js'
        },
        tab: 4
    })
    .unhook('components')
    .hook('node_modules');*/

fis.match('**.js', {
    preprocessor: [
        fis.plugin('annotate'),
        fis.plugin('js-require-css'),
        fis.plugin('js-require-file', {
            useEmbedWhenSizeLessThan: 10 * 1024 /*小于10k用base64*/
        })
    ], optimizer: fis.plugin('uglify-js', {
        mangle: {
            except: 'exports, module, require, define'
        },
        compress: {
            drop_console: true
        }
    }), release: false
}).match('tpl/*.handlebars', {
    rExt: '.js',
    parser: fis.plugin('handlebars-3.x'),
    release: false
}).match('common/(*).js', {
    moduleId: '$1',
    isMod: true
}).match('common/{flexible,fastclick,base64,flipclock}.js', {
    isMod: false
}).match('**.styl', {
    rExt: '.css',
    useHash: false,
    optimizer: fis.plugin('clean-css'),
    preprocessor: fis.plugin('autoprefixer', {
        "browsers": ["Android >= 2.1", "iOS >= 4", "ie >= 8", "firefox >= 15"],
        "cascade": true
    }), parser: fis.plugin('stylus', {
        sourcemap: false
    }), release: false
}).match('*.png', {
    optimizer: fis.plugin('png-compressor') /*图片压缩*/
}).match('{package.json,README.md}', {
    release: false
}).match('/net/(*.cshtml)', {
    release: '$1'
}).match('/img/(**.*)', {
    domain: fis.get('local'),
    release: '/img/$1',
}).match('/net/pc/(**.*)', {
    domain: fis.get('local'),
    release: '/net/pc/$1'
}).match('{app,wechat,img,pc}/**.*', {
    deploy: [
        fis.plugin('local-deliver', {
            to: fis.get('live')
        })
    ]
}).match('**.cshtml', {
    deploy: [
        fis.plugin('local-deliver', {
            to: fis.get('cshtml')
        })
    ]
});

/**
 * pc、m发布
 */
fis.media('net')
    .match('/net/img/(**.*)', {
        domain: fis.get('net'),
        release: '/$1'
    })
    .match('/img/(**.*)', {
        domain: fis.get('net'),
        release: '/m/$1',
    })
    .match('/app/(**.html)', {
        release: false
    })
    .match('/wechat/(**.html)', {
        release: false
    })
    .match('{app,wechat,img}/**.*', {
        deploy: [
            fis.plugin('local-deliver', {
                to: fis.get('pcm')
            })
        ]
    });

/**
 * APP发布
 */
fis.media('app')
    .match('/img/(**.*)', {
        domain: fis.get('app'),
        release: '/$1'
    })
    .match('/app/(**.html)', {
        release: '/app/$1'
    })
    .match('/wechat/(**.html)', {
        release: '/wechat/$1'
    })
    .match('/app/{line,comment,appLine}.html', {
        release: false
    })
    .match('/wechat/line.html', {
        release: false
    })
    .match('/net/img/(**.*)', {
        domain: fis.get('net'),
        release: '../live/$1'
    })
    .match('{app,wechat,img}/**.*', {
        deploy: [
            fis.plugin('local-deliver', {
                to: fis.get('mobile')
            })
        ]
    });