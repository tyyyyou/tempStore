__inline('../common//fn-gettravelpros.js');
__inline('../common/lazyload.js');
seajs.use(['jquery',  'view-lazyload','fn-getTravelPros'], function ($, lazyload, GetTravelPros) {
    var globalObj = {
        terminalType: 'APP',
        traPageId: 36591,
        traLineId_one: 40781,
        traLineId_gn: 40777,
        traLineId_cj: 40778,
        traLineId_zb: 40779,
        traBtnText: '抢购',
        interfaceUrlObj: {
            init: 'http://10.131.10.29:8094/ECommercePlatform/m/bigpromotion/init',
            toCollect: 'https://pages.ch.com/airflights/collectline',
            cancelCollect: 'https://pages.ch.com/airflights/removecollectedline',
            getMyCollects: 'https://pages.ch.com/airflights/getcollectedlines',
            ipLocate: 'https://pages.ch.com/activitiesall/LocateUserCityName'
        },
        collectActivityId: 'Activities689_cn',
        initInterfaceParams: {
            custId: getCustId(),
            userId: getUserId()
        },
        getMyCollectsInterfaceParams: {
            activityId: 'Activities689_cn',
            custId: getCustId(),
            userId: getUserId()
        }
    };

    __inline('../public/common.js');

    var pageObj = {
        init: function () {
            this.bindEvt();
            $('#J_btn_bhhdownload').hide();
        },
        bindEvt: function(){
            $('#J_hotel_nav .J_navitem').click(function(){

            });

            $('#J_btn_bhhrule').click(function(){
                commonObj.openPop($('#J_pop_bhhrule'));
            });
        },
    };

    pageObj.init();
});