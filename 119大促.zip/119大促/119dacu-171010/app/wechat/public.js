var terminalType = 'wechat',
    userId = getPara('userId'),
    custId = getPara('custId'),
    openId = getPara('openid'),
    isInit = true;

if (userId == '' || custId == '') {
    if (openId != '') {
        localStorage.setItem('openId', openId);
        isInit = false;
        $.ajax({
            url: apiConfig.checkLogin.url,
            type: apiConfig.checkLogin.type,
            data: {
                openId: getOpenId()
            },success: function (result) {
                typeof result == "string" && (result = JSON.parse(result));
                if (result.ifSuccess == 'Y') {
                    userId = result.userId;
                    custId = result.custId;
                    localStorage.setItem('userId', userId);
                    localStorage.setItem('custId', custId);
                }
                initData();
            },error: function () {
                initData();
            }
        })
    }
}

userId != '' && localStorage.setItem('userId', userId);
custId != '' && localStorage.setItem('custId', custId);
openId != '' && localStorage.setItem('openId', openId);
function getUserId() {
    var storage = localStorage.getItem('userId');
    if (storage != null && storage != '') {
        return storage;
    }
    return userId;
}

function getCustId() {
    var storage = localStorage.getItem('custId');
    if (storage != null && storage != '') {
        return storage;
    }
    return custId;
}


function getOpenId() {
    var storage = localStorage.getItem('openId');
    if (storage != null && storage != '') {
        return storage;
    }
    return openId;
}

function getPara(name) {
    return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)', 'gi').exec(location.search) || [, ""])[1].replace(/\+/g, '%20')) || '';
}
function is_weixin() {
    var ua = navigator.userAgent.toLowerCase();
    return (ua.match(/MicroMessenger/i) == "micromessenger")
}

function requestLogin(callback) {
    if (getUserId() == '' || getCustId() == '') {
        location.href = apiConfig.wxUrl.url + '?openId=' + getOpenId() + '&addu=Y&reqUrl=' + location.href;
    } else {
        callback && callback();
    }
}

initShare();
function initShare() {
    var urlt = location.href.split('?')[0];
    var reg = new RegExp("&", "g");
    urlt = urlt.replace('?', '@');
    urlt = urlt.replace(reg, '!');
    $.ajax({
        url: "//wx.ch.com/wx/sharewx?baseurl=" + urlt,
        type: 'POST',
        dataType: 'json',
        processData: false,
        success: function (data) {
            appId = data.appId;
            timeStamp = data.timeStamp;
            noncestr = data.noncestr;
            paySign = data.paySign;
            link = urlt;
            wx.config({
                debug: false,
                appId: appId,
                timestamp: timeStamp,
                nonceStr: noncestr,
                signature: paySign,
                jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage', 'hideMenuItems']
            });
            var shareConfig = {
                title: "春秋航空超级品牌日，60小时机票抢不停！",
                desc: "春秋航空超级品牌日，60小时机票抢不停！",
                link: 'http://wx.ch.com/wx/addOpenId?backUrl=http://cms.ch.com/2017/89/index.html ',
                imgUrl: "https://media.springairlines.com/cmsstatic/2017/resource/0327mdshare/mdshare.png"
            }
            wx.ready(function () {
                wx.checkJsApi({jsApiList: ['onMenuShareTimeline', 'hideMenuItems']});
                wx.onMenuShareTimeline({
                    title: shareConfig.title,
                    desc: shareConfig.desc,
                    link: shareConfig.link,
                    imgUrl: shareConfig.imgUrl,
                    success: function () {
                    },
                    cancel: function () {
                    },
                    fail: function (res) {
                        alert("wx.onMenuShareTimeline:fail: " + JSON.stringify(res));
                    }
                });
                wx.onMenuShareAppMessage({
                    title: shareConfig.title,
                    desc: shareConfig.desc,
                    link: shareConfig.link,
                    imgUrl: shareConfig.imgUrl,
                    success: function () {
                    },
                    cancel: function () {
                    },
                    fail: function (res) {
                        alert("wx.onMenuShareAppMessage:fail: " + JSON.stringify(res));
                    }
                });
                wx.hideMenuItems({
                    menuList: ['menuItem:openWithSafari', 'menuItem:copyUrl']
                });
            });
        }
    });
}