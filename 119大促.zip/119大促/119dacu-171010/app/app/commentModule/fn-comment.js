function getUserInfo(obj) {
    try{
        localStorage.clear();
        var res = BASE64.decoder(obj);
        if (res !== "" && res !== undefined && res !== null) {
            localStorage.setItem("userInfo", res);
            var userinfo = JSON.parse(res);
            localStorage.setItem('custId', userinfo.custId);
            localStorage.setItem('userId', userinfo.userId);
            if (location.href.indexOf('isNeedLogin') > -1 || location.href.indexOf('isNeedUserInfo') > -1  ) {
                window.history.go(-1);
            }
        } else {
            localStorage.clear();
        }
        $('#J_btnHidden').click();
    }catch(e){
        alert(e)
    }
}

function getUserId() {
    var userId = localStorage.getItem('userId');
    if (userId == null) {
        return ''
    }
    return userId;
}

function getCustId() {
    var custId = localStorage.getItem('custId');
    if (custId == null) {
        return ''
    }
    return custId;
}
function requestLogin(callback) {
    try{
        var userInfo = JSON.parse(localStorage.getItem("userInfo"));
        if (userInfo !== "" && userInfo !== undefined && userInfo !== null){
            callback && callback();
        }else{
            location.href = location.href.split('?')[0] + '?isNeedLogin=true';
        }
    }catch(e){
        alert(e)
    }
}
function clearInput(){
    document.querySelector('#J-search').value = '';
}
define('fn-appcomment', function(require, exports){
    var $ = require('jquery'), _ = require('underscore'), view = require('view');
    //模板引擎配置
    _.templateSettings = {
        evaluate: /\<\?([\s\S]+?)\?\>/g,
        interpolate: /\<\?=([\s\S]+?)\?\>/g,
        escape: /\<\?-([\s\S]+?)\?\>/g
    };

    function Comment(conf){
        var defaultConf = {
            activityId: '',
            lang: "zh_cn",
            beginTime: "2017-01-01",
            endTime: "2017-12-31",
            pageSize: 10,
            pageIndex: 1,
            lookHref: '',
            isActPage: true
        };
        this.config = $.extend(true, {}, defaultConf, conf);
        this.init();
    }

    /**
     * 初始化
     */
    Comment.prototype.init = function(){
        this.getComment_website();
        this.bindEvt();
    };

    /**
     * 事件绑定集合
     */
    Comment.prototype.bindEvt = function(){
        var _this = this;
        //点赞
        $('body').on('click', '.J-clickzan', function(){
            var $this = $(this);
            requestLogin(function(){
                var userInfo = JSON.parse(localStorage.getItem("userInfo"));
                var userId = userInfo.userId;
                var remarkId = $this.data('remarkid');
                $.ajax({
                    type: "get",
                    url: "http://app.ch.com:9191/ECommercePlatform/m/activityComment/dianzan?userId=" + userId + "&remarkId=" + remarkId,
                    dataType: 'jsonp',
                    beforeSend: function(){
                        view.prototype.$loader.show();
                    },
                    success: function(data) {
                        view.prototype.$loader.show();
                        if (data != "" || data != null || data != undefined) {
                            if (data.IsSuccess == true && data.Result == true) { //点赞成功
                                var $num = $this.find('.i-number');
                                $num.html(parseInt($num.html()) + 1);
                                $this.prepend('<i class="iconfont bg_base_xin i-heart">&#xe63c;</i>');
                                $this.find('.J-heart').remove();
                            } else if (data.IsSuccess == true && data.Result == false) {
                                if (data.Code == "SE_10_01_02") {
                                    alert("您今天已对该评论点过赞了！");
                                } else if (data.Code == "SE01_00_00_00") {
                                    alert("系统异常请稍后再试！");
                                } else if (data.Code == "SE01_00_01_00") {
                                    alert("参数异常！");
                                }
                            } else {
                                alert("抱歉该评论不能点赞！");
                            }
                        } else {
                            alert("系统繁忙,请稍后再试");
                        }
                    },
                    error: function() {
                        alert("系统异常请稍后再试");
                    },
                    complete: function(){
                        view.prototype.$loader.hide();
                    }
                });
            });
        });
        //查看更多按钮
        $("#btn-more").click(function(){
            var $this = $(this);
            if ($this.data("canclick")) {
                $this.data("canclick", false).text("正在加载中....");
                _this.config.pageIndex++;
                _this.getComment_website();
            }
        });
    };
    /**
     * 获取评论
     */
    Comment.prototype.getComment_website = function(){
        var _this = this;
        var data = {
            "PageSize": _this.config.pageSize,
            "PageIndex": _this.config.pageIndex,
            "Condition": {
                "Lang": _this.config.lang,
                "CustId": "",
                "BeginTime": _this.config.beginTime,
                "EndTime": _this.config.endTime,
                "Type": 1,
                "ActivityId": _this.config.activityId
            }
        };
        $.ajax({
            type: "post",
            //url: "https://pages.ch.com/AvtiveComment/QueryRemarkNew",
            url: "http://10.131.10.217:8010/AvtiveComment/QueryRemarkNew",
            data: {"qcParams": JSON.stringify(data)},
            success: function (data) {
                if (data != "" || data != null || data != undefined) {
                    if (data.IsSuccess && data.Result.Data && data.Result.Data.length) {
                        var total = data.Result.Total;
                        if(_this.config.pageIndex == 1){
                            $("#commentWrap").css('backgroundImage', 'none');
                            if(_this.config.isActPage){
                                $("#commentWrap").append([_this.joinTitle(total), _this.joinCommentHtm(data.Result.Data), _this.joinFooter()].join(''));
                            }else{
                                $("#commentWrap").append([_this.joinTitle2(total), _this.joinCommentHtm(data.Result.Data)].join(''));
                            }
                        }else{
                            $("#commentWrap").append(_this.joinCommentHtm(data.Result.Data));
                        }
                        if (total <= (_this.config.pageSize * _this.config.pageIndex)) {
                            $("#btn-more").hide();
                        }
                        $("#btn-more").data("canclick", true).text("加载更多");
                    }else{
                        $("#commentWrap").hide();
                    }
                } else {
                    alert("系统繁忙,请稍后再试");
                }
            },
            error: function () {
            }
        });
    };

    /**
     * 拼接评论头部-活动页底部
     * @param total
     * @returns {string}
     */
    Comment.prototype.joinTitle = function(total){
        return '<p class="each-para-t-sp">' +
            '<span>全部评论(' + total + ')</span>' +
            '<i class="iconfont bg_icon_Arrow i-arr-right">&#xe61d;</i>' +
            '</p>';
    };

    /**
     * 拼接评论底部-活动页底部
     */
    Comment.prototype.joinFooter = function(){
        return '<a class="cm-footer" href="' + this.config.lookHref + '" onclick="clearInput();">查看更多评论</a>';
    };

    /**
     * 拼接评论头部--查看评论页
     * @param total
     * @returns {string}
     */
    Comment.prototype.joinTitle2 = function(total){
        return '<p class="each-para-t"><span>共' + total + '条</span></p>';
    };

    /**
     * 拼接评论字符串
     * @param arr
     * @returns {string}
     */
    Comment.prototype.joinCommentHtm = function(arr){
        var templ = _.template([
            '<? for(var i=0;i< arr.length;i++){ ?>',
            '<?var ctime = new Date(arr[i].Created.toString().replace(/-/g, "/"));?>',
            '<?var ctimeStr = (ctime.getMonth() + 1) + "月" + ctime.getDate() + "日 " + ctime.getHours() + ":" + ctime.getMinutes();?>',
            '<div class="each-para f-cb">',
            '<div class="para1">',
            '<? if(arr[i].userImage){ ?>',
            '<img src="<?=arr[i].userImage ?>" width="100%">',
            '<? }else{ ?>',
            '<img src="//media.springairlines.com/cmsstatic/2017/resource/superfriday/img/pic.png" width="100%">',
            '<? } ?>',
            '</div>',
            '<div class="para2">',
            '<p class="username"><?=arr[i].UserName ?></p>',
            '<div class="general-comment f-cb"><ul class="star_ul fl f-cb" data-level="<?=arr[i].Level ?>"><li></li><li></li><li></li><li></li><li></li></ul></div>',
            '</div>',
            '<p class="para-remark"><?=arr[i].Remark ?></p>',
            '<div class="para3">',
            '<p class="cm-time"><?=ctimeStr ?></p>',
            '<p class="p-like J-clickzan" data-remarkid="<?=arr[i].RemarkID ?>">',
            '<? if(arr[i].OwnSupport){ ?>',
            '<i class="iconfont bg_base_xin i-heart">&#xe63c;</i>',
            '<? }else{ ?>',
            '<i class="iconfont hotel-4 i-heartoff J-heart">&#xe681;</i>',
            '<? } ?>',
            '<span class="i-number"><?=arr[i].SupportNum ?></span></p>',
            '</div>',
            '</div>',
            '<? } ?>'
        ].join(''));
        return templ({arr: arr});
    };

    exports.init = function(conf){
        return new Comment(conf);
    };
});