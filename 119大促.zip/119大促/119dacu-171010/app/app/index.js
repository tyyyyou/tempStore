__inline('../common//fn-gettravelpros.js');
__inline('../common/lazyload.js');
__inline('commentModule/fn-comment.js');
seajs.use(['jquery', 'fn-appcomment','view-lazyload','fn-getTravelPros'], function ($, Comment, lazyload, GetTravelPros) {
    var globalObj = {
        terminalType: 'APP',
        traPageId: 36591,
        traLineId_one: 40781,
        traLineId_gn: 40777,
        traLineId_cj: 40778,
        traLineId_zb: 40779,
        traBtnText: '抢购',
        interfaceUrlObj: {
            toCollect: 'https://pages.ch.com/airflights/collectline',
            cancelCollect: 'https://pages.ch.com/airflights/removecollectedline',
            getMyCollects: 'https://pages.ch.com/airflights/getcollectedlines',
            ipLocate: 'https://pages.ch.com/activitiesall/LocateUserCityName'
        },
        collectActivityId: 'Activities689_cn',
        initInterfaceParams: {
            custId: getCustId(),
            userId: getUserId()
        },
        getMyCollectsInterfaceParams: {
            activityId: 'Activities689_cn',
            custId: getCustId(),
            userId: getUserId()
        }
    };

    __inline('../public/common.js');

    var pageObj = {
        init: function () {
            this.bindEvt();

            $('#J_btn_bhhdownload').hide();

            Comment.init({
                activityId: '2017090101_hotsale',
                lang: "zh_cn",
                beginTime: "2017-01-01",
                endTime: "2017-12-31",
                pageSize: 5,
                pageIndex: 1,
                lookHref: 'lookComment.html',
                isActPage: true
            });
        },
        bindEvt: function(){
            $('#J_hotel_nav .J_navitem').click(function(){

            });

            $('#J_btn_bhhrule').click(function(){
                commonObj.openPop($('#J_pop_bhhrule'));
            });
        },
    };

    pageObj.init();
});